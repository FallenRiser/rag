"""
POST /v1/query   — RAG: embed query → retrieve → rerank → generate answer.
POST /v1/search  — Retrieval-only (no LLM): returns ranked source documents.

Streaming
---------
When query.stream=true, the endpoint returns a Server-Sent Events (SSE)
stream. Each event carries a single token delta from the generator.
The final event contains the complete answer and sources under
data: [DONE].

Example SSE client::

    import httpx, json
    with httpx.stream("POST", ".../v1/query", json={
        "query": "What is deep learning?",
        "stream": True,
    }) as r:
        for line in r.iter_lines():
            if line.startswith("data: "):
                payload = json.loads(line[6:])
                print(payload.get("token", payload), end="", flush=True)
"""

from __future__ import annotations

import json
import logging
import asyncio
import re
import queue
import threading
from typing import Any, AsyncGenerator

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import StreamingResponse

from app.dependencies import get_app_settings, get_registry
from app.schemas.query import (
    QueryRequest,
    QueryResponse,
    SearchRequest,
    SearchResponse,
    SourceDocument,
)
from config.settings import AppSettings
from app.utils.pipeline_registry import PipelineRegistry
from app.utils.user_context import UserContext, require_user
from app.utils.user_isolation import merge_with_user_filter

logger = logging.getLogger(__name__)

router = APIRouter(tags=["query"])


# ---------------------------------------------------------------------------
# POST /v1/query
# ---------------------------------------------------------------------------


@router.post(
    "/query",
    response_model=QueryResponse,
    summary="RAG question answering",
    description=(
        "Performs a full Retrieval-Augmented Generation (RAG) flow to answer a question. "
        "The process includes: query expansion (HyDE), document retrieval with user isolation, "
        "context truncation, and LLM-based answer generation.\n\n"
        "**Key Parameters:**\n"
        "- **query**: The natural language question to be answered.\n"
        "- **pipeline_name**: The name of the pipeline configuration to use (default: 'default').\n"
        "- **top_k**: Number of raw document chunks to retrieve from the vector store (default: 5).\n"
        "- **filters**: Optional Haystack metadata filters (e.g., {'field': 'category', 'operator': '==', 'value': 'legal'}).\n"
        "- **search_type**: Override the retrieval strategy ('embedding', 'bm25', or 'hybrid').\n"
        "- **version**: Query a specific document version. If 0 or omitted, searches the latest version only.\n"
        "- **include_sources**: If true, includes the retrieved document chunks in the response (default: true).\n"
        "- **stream**: If true, returns an SSE stream of answer tokens. Final result includes source metadata.\n"
        "- **max_context_docs**: Maximum number of documents to include in the LLM context window.\n"
        "- **max_chars_per_doc**: Maximum characters to include from each individual document chunk.\n"
        "- **enable_hyde**: Manually enable or disable Hypothetical Document Embeddings for this request."
    ),
)
async def query(
    request: QueryRequest,
    registry: PipelineRegistry = Depends(get_registry),
    settings: AppSettings = Depends(get_app_settings),
    ctx: UserContext = Depends(require_user),
):
    """
    Main RAG query endpoint. Handles both standard and streaming responses.
    
    Coordinates the execution of a RAG pipeline to answer a user's natural language question
    based on their ingested documents. Supports optional HyDE, reranking, and result streaming.

    Parameters
    ----------
    request : QueryRequest
        The request body containing the query string and optional pipeline overrides.
        - query (str): The question to answer.
        - pipeline_name (str): The configuration profile to use (default: "default").
        - stream (bool): Whether to stream tokens via SSE (default: false).
        - top_k (int): Number of chunks to retrieve (default: 5).
        - enable_hyde (bool|None): Override for HyDE query expansion.
    registry : PipelineRegistry, optional
        The registry of pre-built and lazy-loaded Haystack pipelines.
    settings : AppSettings, optional
        The global application settings.
    ctx : UserContext, optional
        The authenticated user's context, containing user_id from X-User-ID header.

    Returns
    -------
    QueryResponse | StreamingResponse
        A JSON response with the answer and sources, or an SSE stream of tokens.
    """
    resolved_name = _resolve_pipeline_name(request, settings, registry)
    _validate_pipeline(resolved_name, registry)

    if request.stream:
        return _stream_response(request, registry, ctx, resolved_name)

    return await _run_query(request, registry, settings, ctx, resolved_name)


async def _run_query(
    request: QueryRequest,
    registry: PipelineRegistry,
    settings: AppSettings,
    ctx: UserContext,
    pipeline_name: str,
) -> QueryResponse:
    """
    Executes a non-streaming query pipeline.

    Parameters
    ----------
    request : QueryRequest
        The original user request parameters.
    registry : PipelineRegistry
        The pipeline registry to fetch the query pipeline from.
    settings : AppSettings
        Application settings for parsing and processing results.
    ctx : UserContext
        User isolation context for filtering retrieved documents.
    pipeline_name : str
        The resolved name of the pipeline to execute.

    Returns
    -------
    QueryResponse
        The structured answer, retrieved source documents, and metadata.

    Raises
    ------
    HTTPException
        500 error if the Haystack pipeline execution fails.
    """
    pipeline = registry.get_query(pipeline_name)
    
    # Check if Multi-Query is enabled
    mq_cfg = settings.query.multi_query
    use_mq = request.enable_multi_query if request.enable_multi_query is not None else mq_cfg.enabled

    if use_mq:
        logger.info(f"Multi-Query enabled for RAG query: '{request.query}'")
        from app.utils.query_pipeline import QueryPipelineBuilder
        builder = QueryPipelineBuilder(settings)
        idx_pipeline = registry.get_indexing(pipeline_name)
        store = idx_pipeline.get_component("writer").document_store
        
        from app.utils.user_isolation import merge_with_user_filter
        isolation_filter = merge_with_user_filter(ctx, request.filters, latest_only=True)
        
        # 1. Retrieve fused documents via multi-query
        docs = await _retrieve_with_multi_query(request, builder, store, isolation_filter)
        logger.info(f"Multi-Query retrieval complete: {len(docs)} fused documents.")
        
        # 2. Build a generation-only pipeline (no retrieval graph conflicts)
        gen_pipeline = builder.build_generation_only()
        
        # 3. Run generation with the fused documents
        run_input = {
            "context_truncator": {"documents": docs},
            "prompt_builder": {"query": request.query},
            "answer_builder": {"query": request.query},
        }
        logger.info(f"Executing generation-only pipeline with {len(docs)} documents.")
        
        try:
            output = gen_pipeline.run(run_input)
        except Exception as exc:
            logger.error(f"Generation pipeline failed: {exc}", exc_info=True)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Multi-Query generation pipeline failed: {exc}",
            )
    else:
        run_input = _build_pipeline_input(request, settings, ctx, pipeline)
        logger.info(f"Executing RAG pipeline '{pipeline_name}' | Query: '{request.query}'")
        logger.debug(f"Pipeline input keys: {list(run_input.keys())}")
        
        try:
            output = pipeline.run(run_input)
        except Exception as exc:
            logger.error(f"Pipeline execution failed: {exc}", exc_info=True)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Query pipeline failed: {exc}",
            )

    # Log the final prompt if available
    if "prompt_builder" in output:
        final_prompt = output["prompt_builder"].get("prompt", "")
        logger.debug(f"--- Final LLM Prompt ---")
        logger.debug(final_prompt)
        logger.debug(f"------------------------")

    response = _parse_result(request, output, settings)
    logger.info(f"RAG complete | Answer length: {len(response.answer)} | Sources: {len(response.sources)}")
    return response



def _build_pipeline_input(
    request: QueryRequest,
    settings: AppSettings,
    ctx: UserContext,
    pipeline: Any,
) -> dict[str, Any]:
    """
    Constructs the input dictionary for the pipeline.run() call.

    Merges mandatory user-isolation filters with user-supplied query parameters
    to ensure data security and apply requested overrides (like top_k or max_docs).

    Parameters
    ----------
    request : QueryRequest
        The incoming query parameters.
    settings : AppSettings
        Global settings for default retrieval/truncation logic.
    ctx : UserContext
        Context used to build the user_id isolation filter.
    pipeline : Any
        The Haystack pipeline instance (used to detect components like HyDE).

    Returns
    -------
    dict[str, Any]
        A dictionary mapping component names to their specific input parameters.
    """
    # Compose user-scoped filter (latest-only by default).
    version = getattr(request, "version", None)
    if version is not None and version > 0:
        from app.utils.user_isolation import version_filter as _vf
        isolation_filter = _vf(ctx, version)
    else:
        isolation_filter = merge_with_user_filter(
            ctx, request.filters, latest_only=True
        )

    search_type = request.search_type or settings.query.retrieval.search_type.value

    inputs: dict[str, Any] = {
        "prompt_builder": {"query": request.query},
        "answer_builder": {"query": request.query},
    }

    # 1. Vector Search components
    if search_type in ["embedding", "hybrid"]:
        if "embedding_retriever" in pipeline.graph.nodes:
            inputs["embedding_retriever"] = {
                "top_k": request.top_k,
                "filters": isolation_filter,
            }

        if "hyde_prompt_builder" in pipeline.graph.nodes:
            inputs["hyde_prompt_builder"] = {"query": request.query}
            inputs["hyde_adapter"] = {"query": request.query}
        elif "text_embedder" in pipeline.graph.nodes:
            inputs["text_embedder"] = {"text": request.query}

    # 2. BM25 Search components
    if search_type in ["bm25", "hybrid"]:
        if "bm25_retriever" in pipeline.graph.nodes:
            inputs["bm25_retriever"] = {
                "query": request.query,
                "top_k": request.top_k,
                "filters": isolation_filter,
            }


    # 3. Reranker
    if "reranker" in pipeline.graph.nodes:
        # Check if it needs a query (LostInTheMiddle doesn't, LLM/Transformers do)
        instance = pipeline.get_component("reranker")
        # LostInTheMiddleRanker doesn't have 'query' in its run() signature.
        if not hasattr(instance, "word_count_threshold"): # A bit hacky but works to detect LitM
             inputs["reranker"] = {"query": request.query}

    # 3. Utilities
    inputs["context_truncator"] = {}
    if request.max_context_docs is not None and request.max_context_docs > 0:
        inputs["context_truncator"]["max_docs"] = request.max_context_docs
    if request.max_chars_per_doc is not None and request.max_chars_per_doc > 0:
        inputs["context_truncator"]["max_chars_per_doc"] = request.max_chars_per_doc

    return inputs


def _get_component_names_safe() -> list[str]:
    """Safe placeholder — actual check happens at pipeline.get_component() level."""
    return []


def _parse_result(
    request: QueryRequest,
    result: dict[str, Any],
    settings: AppSettings,
) -> QueryResponse:
    """
    Parses the raw Haystack pipeline output into a structured QueryResponse.

    Extracts the generated answer string and transforms retrieved Haystack Documents 
    into a serialized SourceDocument format with relevant metadata.

    Parameters
    ----------
    request : QueryRequest
        The original request, used to populate fields like 'query' in the response.
    result : dict[str, Any]
        The output dictionary from pipeline.run().
    settings : AppSettings
        Settings used to determine source limits and metadata inclusion.

    Returns
    -------
    QueryResponse
        A validated Pydantic model containing the answer, sources, and retrieval stats.
    """
    # Answer comes from AnswerBuilder.
    answers = result.get("answer_builder", {}).get("answers", [])
    answer_text = answers[0].data if answers else "No answer generated."

    # Source documents: In Haystack 2.x, pipeline.run() only returns outputs
    # of leaf (terminal) components. context_truncator is intermediate so its
    # output is consumed internally and NOT present in the result dict.
    # Instead, AnswerBuilder receives the documents and attaches them to
    # each GeneratedAnswer object via the .documents attribute.
    raw_docs = []
    if answers and hasattr(answers[0], "documents") and answers[0].documents:
        raw_docs = answers[0].documents

    sources: list[SourceDocument] = []
    if request.include_sources:
        max_sources = settings.query.answer.max_sources
        for doc in raw_docs[:max_sources]:
            meta = doc.meta or {}
            sources.append(
                SourceDocument(
                    document_id=doc.id or "",
                    content=doc.content or "",
                    score=doc.score if settings.query.answer.include_scores else None,
                    source_file=meta.get("source_file"),
                    page_number=meta.get("page_number"),
                    headings=meta.get("headings", []),
                    is_table=meta.get("is_table", False),
                    is_picture=meta.get("is_picture", False),
                    picture_caption=meta.get("picture_caption"),
                    chunk_index=meta.get("chunk_index"),
                )
            )

    return QueryResponse(
        query=request.query,
        answer=answer_text,
        pipeline_name=request.pipeline_name,
        sources=sources,
        meta={
            "sources_retrieved": len(raw_docs),
            "sources_returned": len(sources),
        },
    )


def _stream_response(
    request: QueryRequest,
    registry: PipelineRegistry,
    ctx: UserContext,
    pipeline_name: str,
) -> StreamingResponse:
    """
    Manages token streaming from the LLM generator using Server-Sent Events (SSE).

    Spawns a background thread to run the pipeline, capturing tokens via a callback
    and pushing them into a thread-safe queue consumed by an async generator.

    Parameters
    ----------
    request : QueryRequest
        The query parameters (includes filters, top_k, etc).
    registry : PipelineRegistry
        Registry to borrow the query pipeline from.
    ctx : UserContext
        User context for data isolation during retrieval.
    pipeline_name : str
        The name of the pipeline (with or without HyDE) to execute.

    Returns
    -------
    StreamingResponse
        A FastAPI response that yields tokens in the format 'data: {"token": "..."}\n\n'.
    """
    token_queue: queue.Queue[str | None] = queue.Queue()

    def streaming_callback(chunk: Any) -> None:
        content = getattr(chunk, "content", None) or ""
        if content:
            token_queue.put(content)

    def run_pipeline() -> None:
        try:
            pipeline = registry.get_query(pipeline_name)
            isolation_filter = merge_with_user_filter(ctx, request.filters)
            pipeline_inputs: dict[str, Any] = {
                "prompt_builder": {"query": request.query},
                "answer_builder": {"query": request.query},
                "embedding_retriever": {
                    "top_k": request.top_k,
                    "filters": isolation_filter,
                },
            }
            
            # Use app settings context to check hyde
            from app.dependencies import get_app_settings
            # In stream response we dont pass settings, but we can check pipeline components
            if pipeline.get_component("hyde_prompt_builder"):
                pipeline_inputs["hyde_prompt_builder"] = {"query": request.query}
                pipeline_inputs["hyde_adapter"] = {"query": request.query}
            else:
                pipeline_inputs["text_embedder"] = {"text": request.query}
            
            if request.max_context_docs is not None or request.max_chars_per_doc is not None:
                pipeline_inputs["context_truncator"] = {}
                if request.max_context_docs is not None:
                    pipeline_inputs["context_truncator"]["max_docs"] = request.max_context_docs
                if request.max_chars_per_doc is not None:
                    pipeline_inputs["context_truncator"]["max_chars_per_doc"] = request.max_chars_per_doc

            pipeline.run(
                pipeline_inputs,
                include_outputs_from={
                    "generator": {"streaming_callback": streaming_callback}
                },
            )
        except Exception as exc:
            logger.error("Streaming pipeline error: %s", exc, exc_info=True)
        finally:
            token_queue.put(None)

    thread = threading.Thread(target=run_pipeline, daemon=True)
    thread.start()

    async def event_generator() -> AsyncGenerator[str, None]:
        while True:
            try:
                token = token_queue.get(timeout=60)
            except queue.Empty:
                yield "data: {\"error\": \"stream timeout\"}\n\n"
                break

            if token is None:
                yield "data: [DONE]\n\n"
                break

            payload = json.dumps({"token": token})
            yield f"data: {payload}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


# ---------------------------------------------------------------------------
# POST /v1/search  (retrieval only — no LLM)
# ---------------------------------------------------------------------------


@router.post(
    "/search",
    response_model=SearchResponse,
    summary="Retrieval-only semantic / keyword search",
    description=(
        "Performs a direct search against the document store without invoking an LLM. "
        "Useful for search-only interfaces or for debugging retrieval performance.\n\n"
        "**Key Parameters:**\n"
        "- **query**: The search term or semantic query.\n"
        "- **pipeline_name**: The indexing pipeline whose store should be searched.\n"
        "- **top_k**: Number of results to return (default: 10).\n"
        "- **search_type**: The retrieval method: 'embedding' (vector), 'bm25' (keyword), or 'hybrid' (both).\n"
        "- **filters**: Optional Haystack metadata filters to narrow the search scope."
    ),
)
async def search(
    request: SearchRequest,
    registry: PipelineRegistry = Depends(get_registry),
    settings: AppSettings = Depends(get_app_settings),
    ctx: UserContext = Depends(require_user),
) -> SearchResponse:
    """
    Retrieval-only endpoint (Semantic/Keyword Search).

    Finds relevant document chunks for a query without invoking an LLM for answer generation.
    Supports embedding-based, keyword (BM25), or hybrid search types.

    Parameters
    ----------
    request : SearchRequest
        Parameters for the search operation.
        - query (str): Search term.
        - search_type (str): "embedding", "bm25", or "hybrid".
        - top_k (int): Number of results to return (default: 10).
    registry : PipelineRegistry
        Used to borrow the document store from the indexing pipeline.
    settings : AppSettings
        Used to initialize the text embedder and retriever components.
    ctx : UserContext
        Mandatory user context for row-level security.

    Returns
    -------
    SearchResponse
        A list of matching source documents and total hit count.
    """
    _validate_pipeline(request.pipeline_name, registry)
    logger.info(f"Search request | Type: {request.search_type} | Query: '{request.query}' | top_k: {request.top_k} | MQ: {request.enable_multi_query}")

    from app.utils.embedding import EmbeddingFactory

    # Build a lightweight retrieval-only pipeline on the fly.
    # We share the document store from the indexing pipeline.
    idx_pipeline = registry.get_indexing(request.pipeline_name)
    writer = idx_pipeline.get_component("writer")
    store = writer.document_store

    # User-scoped filter — always applied for data isolation.
    isolation_filter = merge_with_user_filter(
        ctx, request.filters, latest_only=True
    )
    logger.debug(f"Isolation filter: {isolation_filter}")

    try:
        from app.utils.query_pipeline import QueryPipelineBuilder
        builder = QueryPipelineBuilder(settings)
        
        mq_cfg = settings.query.multi_query
        use_mq = request.enable_multi_query if request.enable_multi_query is not None else mq_cfg.enabled

        if use_mq:
            logger.info(f"Multi-Query search enabled for: '{request.query}'")
            docs = await _retrieve_with_multi_query(request, builder, store, isolation_filter)
        else:
            logger.info(f"Single-query search: type={request.search_type}")
            docs = await _retrieve_single_query(request.query, request, builder, store, isolation_filter)

        logger.info(f"Search retrieval complete: {len(docs)} documents.")

    except Exception as exc:
        logger.error("Search error: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(exc),
        )

    results = [
        SourceDocument(
            document_id=doc.id or "",
            content=doc.content or "",
            score=doc.score,
            source_file=(doc.meta or {}).get("source_file"),
            page_number=(doc.meta or {}).get("page_number"),
            headings=(doc.meta or {}).get("headings", []),
            is_table=(doc.meta or {}).get("is_table", False),
            is_picture=(doc.meta or {}).get("is_picture", False),
            picture_caption=(doc.meta or {}).get("picture_caption"),
            chunk_index=(doc.meta or {}).get("chunk_index"),
        )
        for doc in docs
    ]

    logger.info(f"Search response | Query: '{request.query}' | Results: {len(results)} | Type: {request.search_type}")
    for i, r in enumerate(results[:5]):
        logger.debug(f"  [Result {i}] ID: {r.document_id} | Score: {r.score} | Src: {r.source_file}")

    return SearchResponse(
        query=request.query,
        results=results,
        total=len(results),
        search_type=request.search_type,
    )



def _store_search_fallback(store: Any, request: SearchRequest) -> list[Any]:
    """Deprecated fallback function."""
    return []


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _validate_pipeline(pipeline_name: str, registry: PipelineRegistry) -> None:
    """
    Verifies that a requested pipeline name is actually registered in the system.

    Parameters
    ----------
    pipeline_name : str
        The name to check.
    registry : PipelineRegistry
        The registry containing all valid pipeline configurations.

    Raises
    ------
    HTTPException
        404 error if the pipeline name is unknown.
    """
    if pipeline_name not in registry.registered_names():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                f"Pipeline '{pipeline_name}' is not registered. "
                f"Available: {registry.registered_names()}"
            ),
        )

def _resolve_pipeline_name(request: QueryRequest, settings: AppSettings, registry: PipelineRegistry) -> str:
    """
    Determines which pipeline variant to run based on runtime overrides and config.

    Handles the logic for switching between 'default' and 'default_no_hyde' variants
    based on the 'enable_hyde' parameter in the request.

    Parameters
    ----------
    request : QueryRequest
        The incoming query containing potential HyDE overrides.
    settings : AppSettings
        The global settings containing the default HyDE preference.
    registry : PipelineRegistry
        Used to verify the existence of fallback pipeline variants.

    Returns
    -------
    str
        The name of the pipeline variant that should be executed.
    """
    pipeline_name = request.pipeline_name
    use_hyde = request.enable_hyde if request.enable_hyde is not None else settings.query.hyde.enabled
    
    if not use_hyde and settings.query.hyde.enabled:
        fallback_name = f"{pipeline_name}_no_hyde"
        if fallback_name in registry.registered_names():
            return fallback_name
        else:
            logger.warning("HyDE disable requested but fallback pipeline '%s' not registered. Ignoring.", fallback_name)
    return pipeline_name


# ---------------------------------------------------------------------------
# Multi-Query Retrieval Helpers
# ---------------------------------------------------------------------------

async def _get_multi_query_variants(
    query: str, count: int, builder: "QueryPipelineBuilder"
) -> list[str]:
    """Generates alternative versions of the query using the configured LLM."""
    from haystack import Pipeline
    from haystack.components.builders import ChatPromptBuilder
    from haystack.dataclasses import ChatMessage
    from app.utils.query_pipeline import MultiQueryRewriter

    logger.info(f"Multi-Query: Generating {count} variants for: '{query}'")

    # Build a mini pipeline: ChatPromptBuilder → ChatGenerator → Rewriter
    prompt_tpl = builder.query_cfg.multi_query.prompt
    messages = [ChatMessage.from_user(prompt_tpl)]

    pipeline = Pipeline()
    pipeline.add_component("prompt", ChatPromptBuilder(
        template=messages,
        required_variables=["query", "query_count"],
    ))
    pipeline.add_component("generator", builder._build_generator())
    pipeline.add_component("rewriter", MultiQueryRewriter(count=count))

    pipeline.connect("prompt.prompt", "generator.messages")
    pipeline.connect("generator.replies", "rewriter.replies")

    # Run in a thread pool since Haystack 2.x run() is synchronous
    loop = asyncio.get_running_loop()
    try:
        res = await loop.run_in_executor(
            None,
            lambda: pipeline.run({"prompt": {"query": query, "query_count": count}})
        )
        variants = res["rewriter"]["queries"]
        logger.info(f"Multi-Query: Generated {len(variants)} variants successfully.")
        for i, v in enumerate(variants):
            logger.info(f"  [Variant {i}]: {v}")
        return variants
    except Exception as e:
        logger.warning(f"Multi-Query variant generation failed: {e}. Falling back to original query.", exc_info=True)
        return [query]


def _warm_up_component(comp: Any, label: str) -> None:
    """Call warm_up() on a Haystack component if available."""
    if hasattr(comp, "warm_up"):
        logger.debug("Warming up component: %s", label)
        comp.warm_up()


async def _retrieve_with_multi_query(
    request: "QueryRequest | SearchRequest",
    builder: "QueryPipelineBuilder",
    store: Any,
    isolation_filter: dict[str, Any],
) -> list[Any]:
    """Runs retrieval for multiple query variants in parallel and fuses results."""
    from app.utils.embedding import EmbeddingFactory

    # 1. Generate variants
    count = request.multi_query_count or builder.query_cfg.multi_query.query_count
    variants = await _get_multi_query_variants(request.query, count, builder)

    # Ensure original query is included if not present
    if request.query not in variants:
        variants.insert(0, request.query)

    logger.info(f"Multi-Query: Retrieving for {len(variants)} variants (top_k={request.top_k}).")

    # 2. Pre-warm shared components ONCE (instead of per-variant)
    search_type = getattr(request, "search_type", None) or builder.query_cfg.retrieval.search_type.value
    loop = asyncio.get_running_loop()

    shared_embedder = None
    shared_retriever = None
    shared_bm25 = None

    if search_type in ["embedding", "hybrid"]:
        shared_embedder = EmbeddingFactory(builder.settings.embedding).build_text_embedder()
        _warm_up_component(shared_embedder, "text_embedder (multi-query shared)")
        shared_retriever = builder._build_embedding_retriever(store, request.top_k)
        _warm_up_component(shared_retriever, "embedding_retriever (multi-query shared)")
        logger.info("Multi-Query: Text embedder and retriever warmed up.")

    if search_type in ["bm25", "hybrid"]:
        shared_bm25 = builder._build_bm25_retriever(store, request.top_k)
        _warm_up_component(shared_bm25, "bm25_retriever (multi-query shared)")
        logger.info("Multi-Query: BM25 retriever warmed up.")

    # 3. Parallel retrieval — pass pre-warmed components
    tasks = []
    for variant in variants:
        tasks.append(_retrieve_single_query(
            variant, request, builder, store, isolation_filter,
            text_embedder=shared_embedder,
            embedding_retriever=shared_retriever,
            bm25_retriever=shared_bm25,
        ))

    # Run all retrievals concurrently
    results = await asyncio.gather(*tasks, return_exceptions=True)

    # Handle any exceptions from individual retrievals
    clean_results: list[list[Any]] = []
    for i, (variant, result) in enumerate(zip(variants, results)):
        if isinstance(result, Exception):
            logger.error(f"  Variant {i} ('{variant[:60]}...'): FAILED — {result}", exc_info=result)
            clean_results.append([])
        else:
            logger.info(f"  Variant {i} ('{variant[:60]}...'): {len(result)} docs retrieved.")
            clean_results.append(result)

    # 4. Fuse with RRF
    from app.utils.query_pipeline import rrf_merge
    fused_docs = rrf_merge(clean_results)

    top_k = request.top_k
    final_docs = fused_docs[:top_k]
    logger.info(f"Multi-Query: RRF fusion complete. {len(fused_docs)} unique → top {len(final_docs)} returned.")
    for i, doc in enumerate(final_docs):
        logger.debug(f"  [Fused Doc {i}] ID: {doc.id} | Score: {doc.score:.6f} | Src: {(doc.meta or {}).get('source_file', '?')}")

    return final_docs


async def _retrieve_single_query(
    query: str,
    request: "QueryRequest | SearchRequest",
    builder: "QueryPipelineBuilder",
    store: Any,
    isolation_filter: dict[str, Any],
    *,
    text_embedder: Any | None = None,
    embedding_retriever: Any | None = None,
    bm25_retriever: Any | None = None,
) -> list[Any]:
    """Executes a single-query retrieval branch (Embedding, BM25, or Hybrid).

    Parameters
    ----------
    text_embedder, embedding_retriever, bm25_retriever:
        Optional pre-warmed components (shared by multi-query orchestrator).
        If not provided, fresh components are created and warmed up here.
    """
    from app.utils.embedding import EmbeddingFactory

    docs = []
    # QueryRequest has Optional search_type, SearchRequest has required search_type
    search_type = getattr(request, "search_type", None) or builder.query_cfg.retrieval.search_type.value
    loop = asyncio.get_running_loop()

    # ── 1. Vector Search Branch ───────────────────────────────────────
    if search_type in ["embedding", "hybrid"]:
        # Use pre-warmed embedder or create & warm a fresh one
        if text_embedder is None:
            text_embedder = EmbeddingFactory(builder.settings.embedding).build_text_embedder()
            _warm_up_component(text_embedder, "text_embedder (standalone)")

        # Bind query to avoid lambda closure over loop variable
        _q = query
        embed_result = await loop.run_in_executor(None, lambda q=_q: text_embedder.run(text=q))
        query_embedding = embed_result["embedding"]
        logger.debug(f"Embedded query '{query[:50]}...' → vector dim={len(query_embedding)}")

        # Use pre-warmed retriever or create & warm a fresh one
        if embedding_retriever is None:
            embedding_retriever = builder._build_embedding_retriever(store, request.top_k)
            _warm_up_component(embedding_retriever, "embedding_retriever (standalone)")

        _emb = query_embedding
        v_result = await loop.run_in_executor(
            None,
            lambda emb=_emb: embedding_retriever.run(query_embedding=emb, filters=isolation_filter)
        )
        docs = v_result.get("documents", [])

    # ── 2. BM25 Search Branch ─────────────────────────────────────────
    if search_type in ["bm25", "hybrid"]:
        # Use pre-warmed BM25 retriever or create & warm a fresh one
        if bm25_retriever is None:
            bm25_retriever = builder._build_bm25_retriever(store, request.top_k)
            _warm_up_component(bm25_retriever, "bm25_retriever (standalone)")

        _q = query
        b_result = await loop.run_in_executor(
            None,
            lambda q=_q: bm25_retriever.run(query=q, filters=isolation_filter)
        )
        b_docs = b_result.get("documents", [])

        if search_type == "hybrid":
            from haystack.components.joiners import DocumentJoiner
            joiner = DocumentJoiner(join_mode="reciprocal_rank_fusion")
            merged = joiner.run(documents=[docs, b_docs])
            docs = merged.get("documents", [])
        else:
            docs = b_docs

    # ── 3. Reranking (optional) ───────────────────────────────────────
    reranker_strategy = request.reranker or builder.query_cfg.reranker.strategy.value
    if reranker_strategy != "none" and docs:
        ranker_builders = {
            "lost_in_middle": builder._build_lost_in_middle_ranker,
            "llm":            builder._build_llm_ranker,
            "cross_encoder":  builder._build_cross_encoder_ranker,
        }
        ranker_builder = ranker_builders.get(reranker_strategy)
        if ranker_builder:
            ranker = ranker_builder()
            _warm_up_component(ranker, f"reranker ({reranker_strategy})")
            _q = query
            _docs = docs
            if reranker_strategy == "lost_in_middle":
                rank_result = await loop.run_in_executor(None, lambda d=_docs: ranker.run(documents=d))
            else:
                rank_result = await loop.run_in_executor(None, lambda q=_q, d=_docs: ranker.run(query=q, documents=d))
            docs = rank_result.get("documents", [])

    return docs
