"""
BM25 Persistent Store
=====================

Provides a persistent BM25 keyword index that works with **any** primary
vector store backend (ChromaDB, PgVector, Qdrant, Weaviate, InMemory).

Architecture
------------
Haystack's ``InMemoryBM25Retriever`` requires an ``InMemoryDocumentStore``.
Most production vector databases do NOT natively support BM25.

This module solves that by maintaining a **parallel** ``InMemoryDocumentStore``
that is:

1. **Persisted to disk** via a lightweight SQLite database, so the BM25 index
   survives server restarts without re-embedding.
2. **Automatically synced** during document ingestion — whenever new documents
   are written to the primary store, their text content and metadata are
   mirrored into the BM25 store.
3. **Hydrated on startup** from the SQLite snapshot, so queries are available
   immediately without needing to re-ingest.

SQLite was chosen because:
  - Zero external dependencies (ships with Python stdlib).
  - Works on every OS (Windows, Linux, macOS).
  - File-based — no database server required.
  - Fast enough for BM25 text index persistence (read-heavy workload).

Usage
-----
::

    from app.utils.bm25_persistence import BM25PersistenceManager

    manager = BM25PersistenceManager(persist_path="./bm25_data/bm25_index.db")
    bm25_store = manager.get_store()         # InMemoryDocumentStore ready for BM25Retriever
    manager.sync_documents(new_documents)     # After ingesting into primary store
    manager.remove_documents(filters={...})   # When documents are deleted/versioned
"""

from __future__ import annotations

import json
import logging
import sqlite3
import threading
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Default persistence path
_DEFAULT_PERSIST_PATH = "./bm25_data/bm25_index.db"


class BM25PersistenceManager:
    """
    Manages a persistent BM25 index backed by SQLite + InMemoryDocumentStore.

    Parameters
    ----------
    persist_path : str
        Path to the SQLite database file. Parent directories are created
        automatically if they don't exist.
        Default: ``./bm25_data/bm25_index.db``
    bm25_tokenization_regex : str
        Regex used for BM25 tokenization in the InMemoryDocumentStore.
        Default: ``(?u)\\b\\w\\w+\\b`` (unicode word tokens, ≥ 2 chars).
    bm25_algorithm : str
        The BM25 algorithm variant. Options: ``BM25Okapi``, ``BM25L``, ``BM25Plus``.
        Default: ``BM25Okapi``.
    """

    def __init__(
        self,
        persist_path: str = _DEFAULT_PERSIST_PATH,
        bm25_tokenization_regex: str = r"(?u)\b\w\w+\b",
        bm25_algorithm: str = "BM25Okapi",
    ) -> None:
        self._persist_path = Path(persist_path)
        self._bm25_regex = bm25_tokenization_regex
        self._bm25_algorithm = bm25_algorithm
        self._lock = threading.RLock()
        self._store = None  # Lazy init

        # Ensure parent directory exists.
        self._persist_path.parent.mkdir(parents=True, exist_ok=True)

        # Initialize SQLite schema.
        self._init_db()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_store(self) -> Any:
        """
        Returns the ``InMemoryDocumentStore`` instance, hydrated from SQLite.

        The store is lazily initialized on first access and cached for the
        lifetime of this manager.

        Returns
        -------
        InMemoryDocumentStore
            A Haystack InMemoryDocumentStore pre-loaded with all persisted documents.
        """
        with self._lock:
            if self._store is None:
                self._store = self._create_and_hydrate_store()
            return self._store

    def sync_documents(self, documents: list[Any]) -> int:
        """
        Sync newly ingested documents into the BM25 store and persist them.

        This should be called after a successful primary store write during
        document ingestion. Only text content and metadata are stored — embeddings
        are not needed for BM25 and are stripped to save space.

        Parameters
        ----------
        documents : list[Document]
            Haystack Document objects to sync. Each must have `.id`, `.content`,
            and `.meta` attributes.

        Returns
        -------
        int
            Number of documents successfully synced.
        """
        if not documents:
            return 0

        with self._lock:
            store = self.get_store()
            synced = 0

            # Write to InMemoryDocumentStore.
            from haystack import Document

            bm25_docs = []
            for doc in documents:
                bm25_doc = Document(
                    id=doc.id,
                    content=doc.content or "",
                    meta=dict(doc.meta) if doc.meta else {},
                )
                bm25_docs.append(bm25_doc)

            if bm25_docs:
                store.write_documents(bm25_docs, policy="overwrite")
                synced = len(bm25_docs)

            # Persist to SQLite.
            self._persist_documents(bm25_docs)

            logger.info(
                "BM25PersistenceManager: synced %d document(s) → store + SQLite.",
                synced,
            )
            return synced

    def remove_documents(
        self,
        document_ids: list[str] | None = None,
        filters: dict[str, Any] | None = None,
    ) -> int:
        """
        Remove documents from both the in-memory BM25 store and the SQLite persistence.

        Parameters
        ----------
        document_ids : list[str] | None
            Specific document IDs to remove.
        filters : dict[str, Any] | None
            Haystack metadata filter to match documents for removal.

        Returns
        -------
        int
            Number of documents removed.
        """
        with self._lock:
            store = self.get_store()
            removed = 0

            if document_ids:
                store.delete_documents(document_ids=document_ids)
                self._delete_from_db(document_ids)
                removed = len(document_ids)

            if filters:
                # For filter-based removal, we need to find matching doc IDs first.
                from haystack.document_stores.in_memory import InMemoryDocumentStore
                matching_docs = store.filter_documents(filters=filters)
                ids_to_remove = [d.id for d in matching_docs if d.id]
                if ids_to_remove:
                    store.delete_documents(document_ids=ids_to_remove)
                    self._delete_from_db(ids_to_remove)
                    removed += len(ids_to_remove)

            logger.info("BM25PersistenceManager: removed %d document(s).", removed)
            return removed

    def rebuild_from_primary_store(self, primary_store: Any) -> int:
        """
        Fully rebuild the BM25 index from the primary document store.

        Use this for initial hydration or periodic reconciliation.
        Reads ALL documents from the primary store and syncs them.

        Parameters
        ----------
        primary_store : Any
            The primary Haystack document store (ChromaDB, PgVector, etc.).

        Returns
        -------
        int
            Number of documents synced.
        """
        with self._lock:
            logger.info("BM25PersistenceManager: rebuilding from primary store…")

            # Fetch all documents from primary store.
            all_docs = primary_store.filter_documents()

            if not all_docs:
                logger.info("BM25PersistenceManager: primary store is empty — nothing to rebuild.")
                return 0

            # Clear existing data.
            self._clear_db()

            # Reset in-memory store.
            self._store = None
            store = self.get_store()

            # Write all documents.
            from haystack import Document

            bm25_docs = [
                Document(
                    id=doc.id,
                    content=doc.content or "",
                    meta=dict(doc.meta) if doc.meta else {},
                )
                for doc in all_docs
            ]

            store.write_documents(bm25_docs, policy="overwrite")
            self._persist_documents(bm25_docs)

            logger.info(
                "BM25PersistenceManager: rebuilt index with %d document(s).",
                len(bm25_docs),
            )
            return len(bm25_docs)

    def document_count(self) -> int:
        """
        Returns the number of documents currently in the BM25 store.

        Returns
        -------
        int
            Total document count.
        """
        return self.get_store().count_documents()

    # ------------------------------------------------------------------
    # SQLite persistence layer
    # ------------------------------------------------------------------

    def _init_db(self) -> None:
        """Create the SQLite schema if it doesn't exist."""
        conn = sqlite3.connect(str(self._persist_path))
        try:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS bm25_documents (
                    id          TEXT PRIMARY KEY,
                    content     TEXT NOT NULL,
                    meta_json   TEXT NOT NULL DEFAULT '{}'
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_bm25_doc_id
                ON bm25_documents(id)
            """)
            conn.commit()
            logger.debug("BM25PersistenceManager: SQLite schema initialized at %s", self._persist_path)
        finally:
            conn.close()

    def _persist_documents(self, documents: list[Any]) -> None:
        """Insert or replace documents in the SQLite database."""
        if not documents:
            return

        conn = sqlite3.connect(str(self._persist_path))
        try:
            conn.executemany(
                """
                INSERT OR REPLACE INTO bm25_documents (id, content, meta_json)
                VALUES (?, ?, ?)
                """,
                [
                    (
                        doc.id,
                        doc.content or "",
                        json.dumps(doc.meta if doc.meta else {}, default=str),
                    )
                    for doc in documents
                ],
            )
            conn.commit()
        finally:
            conn.close()

    def _delete_from_db(self, document_ids: list[str]) -> None:
        """Delete specific documents from SQLite."""
        if not document_ids:
            return

        conn = sqlite3.connect(str(self._persist_path))
        try:
            placeholders = ",".join(["?"] * len(document_ids))
            conn.execute(
                f"DELETE FROM bm25_documents WHERE id IN ({placeholders})",
                document_ids,
            )
            conn.commit()
        finally:
            conn.close()

    def _clear_db(self) -> None:
        """Delete all rows from the SQLite table."""
        conn = sqlite3.connect(str(self._persist_path))
        try:
            conn.execute("DELETE FROM bm25_documents")
            conn.commit()
        finally:
            conn.close()

    def _load_all_from_db(self) -> list[Any]:
        """Load all documents from SQLite as Haystack Document objects."""
        from haystack import Document

        conn = sqlite3.connect(str(self._persist_path))
        docs = []
        try:
            cursor = conn.execute("SELECT id, content, meta_json FROM bm25_documents")
            for row in cursor:
                doc_id, content, meta_json = row
                try:
                    meta = json.loads(meta_json) if meta_json else {}
                except json.JSONDecodeError:
                    meta = {}
                docs.append(Document(id=doc_id, content=content, meta=meta))
        finally:
            conn.close()

        return docs

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _create_and_hydrate_store(self) -> Any:
        """Create a fresh InMemoryDocumentStore and load persisted documents."""
        from haystack.document_stores.in_memory import InMemoryDocumentStore

        store = InMemoryDocumentStore(
            bm25_tokenization_regex=self._bm25_regex,
            bm25_algorithm=self._bm25_algorithm,
        )

        # Hydrate from SQLite.
        persisted_docs = self._load_all_from_db()
        if persisted_docs:
            store.write_documents(persisted_docs, policy="overwrite")
            logger.info(
                "BM25PersistenceManager: hydrated %d document(s) from SQLite.",
                len(persisted_docs),
            )
        else:
            logger.info("BM25PersistenceManager: no persisted documents found — starting empty.")

        return store


# ---------------------------------------------------------------------------
# Module-level singleton — shared across the application.
# ---------------------------------------------------------------------------

_manager: BM25PersistenceManager | None = None
_manager_lock = threading.Lock()


def get_bm25_manager(
    persist_path: str = _DEFAULT_PERSIST_PATH,
    **kwargs: Any,
) -> BM25PersistenceManager:
    """
    Returns the module-level singleton ``BM25PersistenceManager``.

    Thread-safe. The manager is created on first call and reused thereafter.

    Parameters
    ----------
    persist_path : str
        SQLite file path (only used on first initialization).
    **kwargs
        Additional keyword arguments passed to ``BM25PersistenceManager.__init__``.

    Returns
    -------
    BM25PersistenceManager
        The shared persistence manager instance.
    """
    global _manager
    if _manager is None:
        with _manager_lock:
            if _manager is None:  # Double-checked locking.
                _manager = BM25PersistenceManager(persist_path=persist_path, **kwargs)
    return _manager


def get_bm25_store(
    persist_path: str = _DEFAULT_PERSIST_PATH,
) -> Any:
    """
    Convenience function — returns the InMemoryDocumentStore from the singleton manager.

    This is the function imported by ``query_pipeline.py`` for the BM25 retriever fallback.

    Parameters
    ----------
    persist_path : str
        SQLite file path (only used if the manager hasn't been initialized yet).

    Returns
    -------
    InMemoryDocumentStore
        A ready-to-use store for ``InMemoryBM25Retriever``.
    """
    return get_bm25_manager(persist_path=persist_path).get_store()
