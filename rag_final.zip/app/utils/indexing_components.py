from typing import List, Dict, Any
from haystack import component, Document

@component
class MetadataEnricher:
    """
    Adds structured metadata to every Document.
    Enforces multi-tenancy by strictly applying user_id, document_version, and doc_id
    to all chunks.
    """
    def __init__(self, user_id: str, doc_name: str, doc_version: str):
        self.user_id = user_id
        self.doc_name = doc_name
        self.doc_version = doc_version

    @component.output_types(documents=List[Document])
    def run(self, documents: List[Document]) -> dict:
        enriched = []
        for i, doc in enumerate(documents):
            meta = doc.meta.copy() if doc.meta else {}
            meta["chunk_index"] = i
            meta["user_id"] = self.user_id
            meta["document_name"] = self.doc_name
            meta["document_version"] = self.doc_version
            meta.setdefault("source_file", meta.get("file_path", "unknown"))
            meta.setdefault("page_number", meta.get("page_no", None))
            
            # Docling populates dl_meta with bbox, headings etc.
            if "dl_meta" in meta:
                dl = meta["dl_meta"]
                meta["headings"] = dl.get("headings", [])
                meta["origin"] = dl.get("origin", {})
            enriched.append(Document(content=doc.content, meta=meta, id=doc.id))
        return {"documents": enriched}


@component
class VersionManager:
    """
    Pre-processor step that deletes existing vectors associated with the exact
    (user_id, document_name) prior to upserting the new versions.
    """
    def __init__(self, document_store, user_id: str, doc_name: str):
        self.document_store = document_store
        self.user_id = user_id
        self.doc_name = doc_name

    @component.output_types(documents=List[Document])
    def run(self, documents: List[Document]) -> dict:
        # Depending on the document store, we apply a delete by filter
        filter_dict = {
            "operator": "AND",
            "conditions": [
                {"field": "meta.user_id", "operator": "==", "value": self.user_id},
                {"field": "meta.document_name", "operator": "==", "value": self.doc_name}
            ]
        }
        
        try:
            # Haystack document stores generally support delete_documents with filters if implemented.
            # Workaround for DBs that do not natively support filter delete in the Python API:
            # First filter, retrieve IDs, then delete by ID.
            if hasattr(self.document_store, "delete_documents"):
                # Warning: Haystack 2.x delete_documents usually expects list of IDs.
                # If filter is not supported implicitly, we must query first.
                docs_to_delete = self.document_store.filter_documents(filters=filter_dict)
                doc_ids = [d.id for d in docs_to_delete]
                if doc_ids:
                    self.document_store.delete_documents(document_ids=doc_ids)
        except Exception as e:
            # Log failure but do not crash pipeline if delete fails or is unsupported
            print(f"Warning: Failed to delete prior document versions for {self.user_id}/{self.doc_name}: {e}")
            
        return {"documents": documents}


@component
class SemanticMetadataExtractor:
    """
    Optional LLM-based categorizer that summarizes or tags the document dynamically.
    Powered by the configured LLM provider.
    """
    def __init__(self, generator_pipeline=None, enabled: bool = False, prompt_template: str = ""):
        self.generator_pipeline = generator_pipeline
        self.enabled = enabled
        self.prompt_template = prompt_template

    @component.output_types(documents=List[Document])
    def run(self, documents: List[Document]) -> dict:
        if not self.enabled or not self.generator_pipeline or not documents:
            return {"documents": documents}

        # Take first document chunk as representative or a sample of chunks.
        # To avoid massive token usage, we extract only based on the first chunk.
        sample_text = documents[0].content
        
        # In a real scenario, we would run an LLM prompt here 
        # tags = self.generator_pipeline.run(...)
        # meta["semantic_tags"] = tags
        
        # Dummy implementation of tagging for simplicity
        tags = ["auto-categorized"]
        
        for doc in documents:
            doc.meta["semantic_tags"] = tags

        return {"documents": documents}
