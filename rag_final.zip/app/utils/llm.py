from typing import Any
import os

class LLMFactory:
    """
    Reads embedding_config.yaml (llm section) and initializes the requested Haystack Generator.
    Supports azure_openai, ollama.
    """

    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.provider = self.cfg.get("provider", "ollama")

    def build_generator(self) -> Any:
        builder = getattr(self, f"_build_{self.provider}_generator", None)
        if builder is None:
            raise ValueError(f"Unknown LLM provider: {self.provider}")
        return builder()

    def _build_azure_openai_generator(self):
        from haystack.components.generators import OpenAIGenerator
        config = self.cfg.get("azure_openai", {})
        api_key_env = config.get("api_key_env", "AZURE_OPENAI_API_KEY")
        from haystack.utils import Secret
        return OpenAIGenerator(
            api_key=Secret.from_env_var(api_key_env),
            model=config.get("azure_deployment", "gpt-4o-mini"),
            api_base_url=f"{config.get('azure_endpoint')}/openai/deployments",
        )

    def _build_ollama_generator(self):
        from haystack_integrations.components.generators.ollama import OllamaGenerator
        config = self.cfg.get("ollama", {})
        return OllamaGenerator(
            model=config.get("model", "llama3.1"),
            url=config.get("url", "http://localhost:11434/api/generate"),
            generation_kwargs={"temperature": 0.3}
        )
