"""
Observability setup — MLflow GenAI Traces + Loguru.

Call ``setup_tracing(settings)`` once during FastAPI lifespan startup.
"""

from __future__ import annotations

import logging
import sys
from typing import TYPE_CHECKING

from loguru import logger

if TYPE_CHECKING:
    from config.settings import AppSettings

class InterceptHandler(logging.Handler):
    """
    Default handler from examples in loguru documentation.
    Intercepts standard logging messages toward your Loguru sinks.
    """
    def emit(self, record: logging.LogRecord) -> None:
        # Get corresponding Loguru level if it exists.
        try:
            level = logger.level(record.levelname).name
        except ValueError:
            level = record.levelno

        # Find caller from where originated the logged message
        frame, depth = logging.currentframe(), 2
        while frame and frame.f_code.co_filename == logging.__file__:
            frame = frame.f_back
            depth += 1

        logger.opt(depth=depth, exception=record.exc_info).log(level, record.getMessage())

def setup_tracing(settings: "AppSettings") -> None:
    """
    Initialise Loguru and MLflow GenAI tracing.
    """
    _setup_loguru(settings.log_level)

    try:
        import mlflow
        # Enable MLflow tracing
        mlflow.set_tracking_uri(settings.mlflow_tracking_uri)
        logger.info(f"MLflow tracking URI set: {mlflow.get_tracking_uri()}")
        
        mlflow.set_experiment(settings.mlflow_experiment_name)
        logger.info(f"MLflow experiment set: {settings.mlflow_experiment_name}")

        # Enable Haystack autologging for GenAI traces
        try:
            import mlflow.haystack
            mlflow.haystack.autolog(
                log_traces=True     # Don't log model artifacts (saves space)
            )
            logger.info("Haystack autologging enabled (log_traces=True).")
        except (ImportError, AttributeError) as e:
            logger.warning(f"mlflow.haystack.autolog() not available: {e}")

        # Also enable tracing for any OpenAI/Ollama calls if available
        try:
            if hasattr(mlflow, 'openai'):
                mlflow.openai.autolog()
                logger.info("OpenAI autologging enabled.")
        except Exception:
            pass

        # Verify tracing is active
        logger.info(
            "MLflow tracing enabled → %s | Experiment: %s",
            mlflow.get_tracking_uri(),
            settings.mlflow_experiment_name,
        )
    except ImportError as exc:
        logger.warning(
            "MLflow package not installed; tracing disabled. "
            "Run: pip install mlflow\n"
            "Error: %s",
            exc,
        )

def _setup_loguru(log_level: str) -> None:
    """Configure Loguru to intercept standard logging and format it."""
    logging.basicConfig(handlers=[InterceptHandler()], level=0, force=True)
    logger.remove()
    logger.add(sys.stderr, level=log_level.upper(), enqueue=True)
