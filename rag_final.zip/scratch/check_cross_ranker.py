
import inspect
try:
    from haystack.components.rankers import TransformersSimilarityRanker
    print(f"TransformersSimilarityRanker __init__ signature: {inspect.signature(TransformersSimilarityRanker.__init__)}")
except ImportError:
    print("TransformersSimilarityRanker not found")
except Exception as e:
    print(f"Error: {e}")
