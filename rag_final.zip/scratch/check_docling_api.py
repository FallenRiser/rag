from docling.datamodel.pipeline_options import (
    PdfPipelineOptions,
    WordPipelineOptions,
    HtmlPipelineOptions,
    PptxPipelineOptions,
)
import inspect

def print_params(cls):
    sig = inspect.signature(cls.__init__)
    print(f"{cls.__name__}: {list(sig.parameters.keys())}")

print_params(PdfPipelineOptions)
print_params(WordPipelineOptions)
print_params(HtmlPipelineOptions)
print_params(PptxPipelineOptions)
