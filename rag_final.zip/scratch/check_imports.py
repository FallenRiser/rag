try:
    from docling_core.transforms.chunker.table_serializer import MarkdownTableSerializer
    print("MarkdownTableSerializer found at docling_core.transforms.chunker.table_serializer")
except ImportError:
    try:
        from docling_core.transforms.chunker import MarkdownTableSerializer
        print("MarkdownTableSerializer found at docling_core.transforms.chunker")
    except ImportError:
        print("MarkdownTableSerializer NOT found")
