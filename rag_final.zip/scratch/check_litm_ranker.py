
import inspect
try:
    from haystack.components.rankers import LostInTheMiddleRanker
    print(f"LostInTheMiddleRanker.run signature: {inspect.signature(LostInTheMiddleRanker.run)}")
except ImportError:
    print("LostInTheMiddleRanker not found")
except Exception as e:
    print(f"Error: {e}")
