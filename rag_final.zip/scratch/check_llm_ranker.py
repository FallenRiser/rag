
import inspect
try:
    from haystack.components.rankers import LLMRanker
    print(f"LLMRanker __init__ signature: {inspect.signature(LLMRanker.__init__)}")
except ImportError:
    print("LLMRanker not found")
except Exception as e:
    print(f"Error: {e}")
