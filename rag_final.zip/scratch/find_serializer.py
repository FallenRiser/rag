import os
import docling_core

root = os.path.dirname(docling_core.__file__)
found = []
for r, d, f in os.walk(root):
    for file in f:
        if file.endswith(".py"):
            path = os.path.join(r, file)
            with open(path, "r", encoding="utf-8", errors="ignore") as f_obj:
                if "BaseSerializerProvider" in f_obj.read():
                    found.append(path)

if found:
    for p in found:
        print(f"Found in: {p}")
else:
    print("Not found in docling_core")
