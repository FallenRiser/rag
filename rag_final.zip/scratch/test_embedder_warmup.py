"""
Test: prove that SentenceTransformersTextEmbedder fails without warm_up().
"""
import sys
sys.path.append(r"c:\Users\Shlok Sheth\Desktop\rag_pipeline1\rag_final")

from config.settings import get_settings
from app.utils.embedding import EmbeddingFactory

settings = get_settings()
factory = EmbeddingFactory(settings.embedding)

# ── Test 1: WITHOUT warm_up() ──────────────────────────────────────
print("=== Test 1: WITHOUT warm_up() ===")
embedder = factory.build_text_embedder()
try:
    result = embedder.run(text="What are docling features?")
    emb = result.get("embedding", [])
    print(f"  Embedding length: {len(emb)}")
    print(f"  First 5 values: {emb[:5]}")
except Exception as e:
    print(f"  ERROR: {type(e).__name__}: {e}")

# ── Test 2: WITH warm_up() ─────────────────────────────────────────
print("\n=== Test 2: WITH warm_up() ===")
embedder2 = factory.build_text_embedder()
embedder2.warm_up()   # <-- the missing call
try:
    result2 = embedder2.run(text="What are docling features?")
    emb2 = result2.get("embedding", [])
    print(f"  Embedding length: {len(emb2)}")
    print(f"  First 5 values: {emb2[:5]}")
except Exception as e:
    print(f"  ERROR: {type(e).__name__}: {e}")
