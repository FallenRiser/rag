
from typing import List
from haystack import Pipeline, component, Document

@component
class MockEmbedder:
    @component.output_types(documents=List[Document])
    def run(self, documents: List[Document]):
        for doc in documents:
            doc.embedding = [0.1, 0.2]
        return {"documents": documents}

@component
class MockWriter:
    @component.output_types(documents_written=int)
    def run(self, documents: List[Document]):
        return {"documents_written": len(documents)}

p = Pipeline()
p.add_component("embedder", MockEmbedder())
p.add_component("writer", MockWriter())
p.connect("embedder.documents", "writer.documents")

docs = [Document(content="hello")]
output = p.run({"embedder": {"documents": docs}})

print(f"Output keys: {output.keys()}")
if "embedder" in output:
    print(f"Embedder output found")
if "writer" in output:
    print(f"Writer output found: {output['writer']}")
