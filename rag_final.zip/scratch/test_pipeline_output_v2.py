
from typing import List, Set
from haystack import Pipeline, component, Document

@component
class MockEmbedder:
    @component.output_types(documents=List[Document])
    def run(self, documents: List[Document]):
        return {"documents": documents}

@component
class MockWriter:
    @component.output_types(documents_written=int)
    def run(self, documents: List[Document]):
        return {"documents_written": len(documents)}

p = Pipeline()
p.add_component("embedder", MockEmbedder())
p.add_component("writer", MockWriter())
p.connect("embedder.documents", "writer.documents")

docs = [Document(content="hello")]
# Try include_outputs_from
try:
    output = p.run({"embedder": {"documents": docs}}, include_outputs_from={"embedder"})
    print(f"Output keys with include_outputs_from: {output.keys()}")
except Exception as e:
    print(f"Error with include_outputs_from: {e}")
