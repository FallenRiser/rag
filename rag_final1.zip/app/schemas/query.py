"""
Pydantic v2 schemas for the /v1/query and /v1/search endpoints.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

from app.schemas.filters import SimpleFilter


class MetadataFilter(BaseModel):
    """Haystack-compatible metadata filter expression."""

    field: str
    operator: str = Field(
        description="==, !=, >, >=, <, <=, in, not in, AND, OR, NOT"
    )
    value: Any


# ---------------------------------------------------------------------------
# Query request/response
# ---------------------------------------------------------------------------


class QueryRequest(BaseModel):
    query: str = Field(..., min_length=1, max_length=4096)
    pipeline_name: str = Field(default="default")
    top_k: int = Field(default=5, ge=1, le=50)
    filters: SimpleFilter | None = Field(
        default=None,
        description="""Optional user-friendly filter using MongoDB-style operators.

        Supported operators:
        - $eq: equals (default)
        - $ne: not equals
        - $gt: greater than
        - $gte: greater than or equal
        - $lt: less than
        - $lte: less than or equal
        - $in: in array/list
        - $and: logical AND (array of conditions)
        - $or: logical OR (array of conditions)

        Available metadata fields:
        - source_name (str): Basename of the ingested file
        - source_file (str): Normalized file path/URL
        - page_number (int|None): Page number in original document
        - chunk_index (int): Position of chunk in document
        - headings (list[str]): Hierarchical headings breadcrumb
        - is_table (bool): Whether chunk contains a table
        - is_picture (bool): Whether chunk contains an image
        - picture_caption (str|None): Caption from VLM enrichment
        - word_count (int): Number of words in chunk
        - char_count (int): Number of characters in chunk
        - version (int): Version number of the document
        - is_latest (bool): Whether this is the latest version
        - user_id (str): Owner of the document (auto-added for isolation)
        - source_hash (str): SHA-256 of raw file bytes
        - ingested_at (str): ISO 8601 UTC timestamp

        Examples:
        - {"source_name": "report.pdf"}
        - {"page_number": {"$gte": 1, "$lte": 10}}
        - {"source_name": {"$in": ["report1.pdf", "report2.pdf"]}}
        - {"is_table": true}
        - {
            "$and": [
                {"source_name": "report.pdf"},
                {"page_number": {"$gte": 5}},
                {"is_table": false}
            ]
          }
        """,
        json_schema_extra={
            "examples": [
                {"source_name": "report.pdf"},
                {"page_number": {"$gte": 1, "$lte": 10}},
                {"source_name": {"$in": ["report1.pdf", "report2.pdf"]}},
                {"is_table": True},
                {
                    "$and": [
                        {"source_name": "report.pdf"},
                        {"page_number": {"$gte": 5}},
                        {"is_table": False}
                    ]
                }
            ]
        }
    )
    search_type: str | None = Field(
        default=None,
        description="Override config search_type: embedding | bm25 | hybrid",
    )
    version: int | None = Field(
        default=None,
        description=(
            "Query a specific historical version of documents. "
            "Omit to query the latest version only (default)."
        ),
    )
    include_sources: bool = Field(default=True)
    stream: bool = Field(
        default=False,
        description="Stream the answer token-by-token via Server-Sent Events.",
    )
    max_context_docs: int | None = Field(
        default=None,
        description="Override config maximum documents for prompt.",
    )
    max_chars_per_doc: int | None = Field(
        default=None,
        description="Override config max chars per doc for prompt.",
    )
    enable_hyde: bool | None = Field(
        default=None,
        description="Override config query expansion (HyDE) setting.",
    )
    reranker: str | None = Field(
        default=None,
        description="Override reranker strategy: none | lost_in_middle | llm | cross_encoder",
    )
    enable_multi_query: bool | None = Field(
        default=None,
        description="Override config multi-query rewriting setting.",
    )
    multi_query_count: int | None = Field(
        default=None,
        ge=2,
        le=5,
        description="Number of query variants to generate (2-5).",
    )
    auto_filter: bool = Field(
        default=False,
        description="If true, dynamically extracts structured filters (like entities) from the user's natural language query using an LLM.",
    )


class SourceDocument(BaseModel):
    """A single retrieved source document included with a query answer."""

    document_id: str
    content: str
    score: float | None = None
    source_file: str | None = None
    page_number: int | None = None
    headings: list[str] = Field(default_factory=list)
    is_table: bool = False
    is_picture: bool = False
    picture_caption: str | None = None
    chunk_index: int | None = None


class QueryResponse(BaseModel):
    query: str
    answer: str
    pipeline_name: str
    sources: list[SourceDocument] = Field(default_factory=list)
    meta: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# Search (retrieval-only) request/response
# ---------------------------------------------------------------------------


class SearchRequest(BaseModel):
    query: str = Field(..., min_length=1, max_length=4096)
    pipeline_name: str = Field(default="default")
    top_k: int = Field(default=10, ge=1, le=100)
    filters: SimpleFilter | None = Field(
        None,
        description="""Optional user-friendly filter using MongoDB-style operators.

        Supported operators:
        - $eq: equals (default)
        - $ne: not equals
        - $gt: greater than
        - $gte: greater than or equal
        - $lt: less than
        - $lte: less than or equal
        - $in: in array/list
        - $and: logical AND (array of conditions)
        - $or: logical OR (array of conditions)

        Available metadata fields:
        - source_name (str): Basename of the ingested file
        - source_file (str): Normalized file path/URL
        - page_number (int|None): Page number in original document
        - chunk_index (int): Position of chunk in document
        - headings (list[str]): Hierarchical headings breadcrumb
        - is_table (bool): Whether chunk contains a table
        - is_picture (bool): Whether chunk contains an image
        - picture_caption (str|None): Caption from VLM enrichment
        - word_count (int): Number of words in chunk
        - char_count (int): Number of characters in chunk
        - version (int): Version number of the document
        - is_latest (bool): Whether this is the latest version
        - user_id (str): Owner of the document (auto-added for isolation)
        - source_hash (str): SHA-256 of raw file bytes
        - ingested_at (str): ISO 8601 UTC timestamp

        Examples:
        - {"source_name": "report.pdf"}
        - {"page_number": {"$gte": 1, "$lte": 10}}
        - {"source_name": {"$in": ["report1.pdf", "report2.pdf"]}}
        - {"is_table": true}
        - {
            "$and": [
                {"source_name": "report.pdf"},
                {"page_number": {"$gte": 5}},
                {"is_table": false}
            ]
          }
        """,
        json_schema_extra={
            "examples": [
                {"source_name": "report.pdf"},
                {"page_number": {"$gte": 1, "$lte": 10}},
                {"source_name": {"$in": ["report1.pdf", "report2.pdf"]}},
                {"is_table": True},
                {
                    "$and": [
                        {"source_name": "report.pdf"},
                        {"page_number": {"$gte": 5}},
                        {"is_table": False}
                    ]
                }
            ]
        }
    )
    search_type: str = Field(
        default="embedding",
        description="embedding | bm25 | hybrid",
    )
    reranker: str | None = Field(
        default=None,
        description="Override reranker strategy: none | lost_in_middle | llm | cross_encoder",
    )
    enable_multi_query: bool | None = Field(
        default=None,
        description="Override config multi-query rewriting setting.",
    )
    multi_query_count: int | None = Field(
        default=None,
        ge=2,
        le=5,
        description="Number of query variants to generate (2-5).",
    )


class SearchResponse(BaseModel):
    query: str
    results: list[SourceDocument]
    total: int
    search_type: str
