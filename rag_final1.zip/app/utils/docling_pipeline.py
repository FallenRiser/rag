"""
DoclingPipelineBuilder
======================

Builds a fully configured Haystack 2.x ``DoclingConverter`` from ``DoclingConfig``.

Supported features (all driven by YAML config)
----------------------------------------------
PDF / DOCX / HTML / PPTX / image pipeline options
OCR engines  : EasyOCR | Tesseract | RapidOCR
  Tesseract  : auto-maps ISO 639-1 → Tesseract 3-letter codes
  RapidOCR   : optional config path
Table extraction : TableFormer (accurate | fast), cell matching
Image enrichments:
  Picture description (captioning) via:
    Ollama            — local VLM (granite3.2-vision, llava, moondream…)
    OpenAI-compatible — any /v1/chat/completions endpoint
  Picture classification — built-in Docling classifier
  Code block understanding
  Formula recognition
Export modes : doc_chunks (default) | markdown
HybridChunker: embedded when strategy=document_aware
Device       : cpu | cuda | mps | auto
"""

from __future__ import annotations

import logging
import os

# Restrict PyTorch/OpenMP thread allocation to prevent OOM on large PDFs
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"

from typing import TYPE_CHECKING, Any

from config.models import (
    CaptioningBackend,
    DoclingConfig,
    ExportType,
    FormatPipelineConfig,
    InferenceDevice,
    OcrEngine,
    OpenAICompatibleCaptionConfig,
    OllamaCaptionConfig,
)

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# OCR engine builders
# ---------------------------------------------------------------------------


def _build_easyocr_options(cfg: FormatPipelineConfig) -> Any:
    from docling.datamodel.pipeline_options import EasyOcrOptions
    from pathlib import Path

    # Docling 2.x logic: if DOCLING_ARTIFACTS_PATH is set, Docling forces
    # download_enabled=False UNLESS model_storage_directory is explicitly set.
    # We set it here to the expected sub-path to allow automatic downloads.
    artifacts_path = os.environ.get("DOCLING_ARTIFACTS_PATH")
    storage_dir = None
    if artifacts_path:
        storage_dir = str(Path(artifacts_path) / "EasyOcr")

    return EasyOcrOptions(
        lang=cfg.ocr_options.lang,
        force_full_page_ocr=cfg.ocr_options.force_full_page_ocr,
        model_storage_directory=storage_dir,
        download_enabled=True,
    )


def _build_tesseract_options(cfg: FormatPipelineConfig) -> Any:
    from docling.datamodel.pipeline_options import TesseractCliOcrOptions

    _lang_map = {
        "en": "eng", "de": "deu", "fr": "fra", "es": "spa",
        "it": "ita", "pt": "por", "nl": "nld", "zh": "chi_sim",
        "ja": "jpn", "ko": "kor", "ar": "ara", "ru": "rus",
    }
    # langs = "+".join(_lang_map.get(l, l) for l in cfg.ocr_options.lang)
    
    langs = [
            _lang_map.get(l, l)
            for l in cfg.ocr_options.lang
        ]

    return TesseractCliOcrOptions(
        lang=langs,
        force_full_page_ocr=cfg.ocr_options.force_full_page_ocr,
    )


def _build_rapidocr_options(cfg: FormatPipelineConfig) -> Any:
    from docling.datamodel.pipeline_options import RapidOcrOptions
    kwargs: dict[str, Any] = {
        "force_full_page_ocr": cfg.ocr_options.force_full_page_ocr,
    }
    if cfg.ocr_options.rapidocr_config_path:
        kwargs["config_path"] = str(cfg.ocr_options.rapidocr_config_path)
    return RapidOcrOptions(**kwargs)


def _build_ocr_options(cfg: FormatPipelineConfig) -> Any:
    return {
        OcrEngine.EASYOCR:   _build_easyocr_options,
        OcrEngine.TESSERACT: _build_tesseract_options,
        OcrEngine.RAPIDOCR:  _build_rapidocr_options,
    }.get(cfg.ocr_engine, _build_easyocr_options)(cfg)


# ---------------------------------------------------------------------------
# Format pipeline options
# ---------------------------------------------------------------------------


def _build_pdf_options(cfg: DoclingConfig, captioner: Any = None) -> Any:
    from docling.datamodel.pipeline_options import (
        PdfPipelineOptions,
        TableStructureOptions,
        TableFormerMode,
        AcceleratorOptions,
    )
    mode = (
        TableFormerMode.ACCURATE
        if cfg.pdf.table_structure_options.mode.value == "accurate"
        else TableFormerMode.FAST
    )
    # Enrichments
    do_caption = captioner is not None
    do_classify = cfg.enrichments.picture_classification_enabled
    do_code = cfg.enrichments.code_understanding_enabled
    do_formula = cfg.enrichments.formula_understanding_enabled

    # Build kwargs conditionally — Docling's PdfPipelineOptions rejects None for
    # ocr_options and picture_description_options; omit them entirely when disabled.
    kwargs: dict[str, Any] = dict(
        do_ocr=cfg.pdf.do_ocr,
        do_table_structure=cfg.pdf.do_table_structure,
        table_structure_options=TableStructureOptions(
            mode=mode,
            do_cell_matching=cfg.pdf.table_structure_options.do_cell_matching,
        ),
        generate_page_images=cfg.pdf.generate_page_images,
        generate_picture_images=cfg.pdf.generate_picture_images,
        images_scale=cfg.pdf.images_scale,

        # Docling 2.x enrichment flags
        do_picture_description=do_caption,
        do_picture_classification=do_classify,
        do_code_enrichment=do_code,
        do_formula_enrichment=do_formula,

        # Memory Optimization: Restrict concurrency
        # (these are no-ops for SimplePdfPipeline but harmless)
        accelerator_options=AcceleratorOptions(num_threads=1),

        # CRITICAL: Allow connection to Ollama/OpenAI
        enable_remote_services=do_caption,
    )

    # Only inject optional instance fields when they are actually enabled
    if cfg.pdf.do_ocr:
        kwargs["ocr_options"] = _build_ocr_options(cfg.pdf)
    if do_caption:
        kwargs["picture_description_options"] = captioner

    return PdfPipelineOptions(**kwargs)


def _build_format_options(cfg: DoclingConfig) -> dict[Any, Any]:
    try:
        from docling.datamodel.base_models import InputFormat
        from docling.document_converter import PdfFormatOption
    except ImportError as exc:
        raise ImportError("Run: pip install docling") from exc

    # Pre-build captioner to pass into options
    captioner = _build_picture_description(cfg)

    # Use SimplePdfPipeline to avoid page rasterization on large documents.
    # StandardPdfPipeline's PagePreprocessingModel renders EVERY page as a bitmap
    # for the layout AI model (RT-DETR), regardless of generate_page_images setting.
    # SimplePdfPipeline extracts text natively from the PDF text layer — no page
    # rendering, no layout neural network, no std::bad_alloc OOM on large PDFs.
    pdf_format_kwargs: dict[str, Any] = {
        "pipeline_options": _build_pdf_options(cfg, captioner),
    }
    try:
        from docling.pipeline.simple_pdf_pipeline import SimplePdfPipeline
        pdf_format_kwargs["pipeline_cls"] = SimplePdfPipeline
        logger.info(
            "PDF pipeline: SimplePdfPipeline (memory-optimized, native text extraction)"
        )
    except ImportError:
        logger.warning(
            "SimplePdfPipeline not available — falling back to StandardPdfPipeline. "
            "Large PDFs may OOM."
        )

    options: dict[Any, Any] = {
        InputFormat.PDF: PdfFormatOption(**pdf_format_kwargs)
    }

    # DOCX
    try:
        from docling.document_converter import WordFormatOption
        from docling.datamodel.pipeline_options import WordPipelineOptions
        options[InputFormat.DOCX] = WordFormatOption(
            pipeline_options=WordPipelineOptions(
                do_ocr=cfg.docx.do_ocr,
                generate_picture_images=cfg.docx.generate_picture_images,
            )
        )
    except Exception:
        pass  # optional; docling uses default for DOCX

    # HTML
    try:
        from docling.document_converter import HtmlFormatOption
        from docling.datamodel.pipeline_options import HtmlPipelineOptions
        options[InputFormat.HTML] = HtmlFormatOption(
            pipeline_options=HtmlPipelineOptions(
                generate_picture_images=cfg.html.generate_picture_images,
            )
        )
    except Exception:
        pass

    # PPTX
    try:
        from docling.document_converter import PowerpointFormatOption
        from docling.datamodel.pipeline_options import PptxPipelineOptions
        options[InputFormat.PPTX] = PowerpointFormatOption(
            pipeline_options=PptxPipelineOptions(
                generate_page_images=cfg.pptx.generate_page_images,
                generate_picture_images=cfg.pptx.generate_picture_images,
            )
        )
    except Exception:
        pass

    return options


# ---------------------------------------------------------------------------
# Enrichment / captioning builders
# ---------------------------------------------------------------------------


def _build_ollama_captioner(cfg: OllamaCaptionConfig) -> Any:
    try:
        from docling.datamodel.pipeline_options import PictureDescriptionApiOptions
        return PictureDescriptionApiOptions(
            url=f"{cfg.base_url.rstrip('/')}/v1/chat/completions",
            params={"model": cfg.model, "temperature": 0.0},
            prompt=cfg.prompt,
            timeout=cfg.timeout_seconds,
        )
    except Exception as exc:
        logger.warning("Could not build Ollama captioner: %s", exc)
        return None


def _build_openai_compatible_captioner(cfg: OpenAICompatibleCaptionConfig) -> Any:
    base_url = os.environ.get(cfg.base_url_env, "")
    api_key  = os.environ.get(cfg.api_key_env, "")
    if not base_url or not api_key:
        msg = f"OpenAI-compatible captioning: env {cfg.base_url_env} or {cfg.api_key_env} not set"
        if cfg.fail_on_error:
            raise EnvironmentError(msg)
        logger.warning(msg)
        return None
    try:
        from docling.datamodel.pipeline_options import PictureDescriptionApiOptions
        return PictureDescriptionApiOptions(
            url=f"{base_url.rstrip('/')}/chat/completions",
            params={"model": cfg.model, "max_tokens": cfg.max_tokens},
            headers={"Authorization": f"Bearer {api_key}"},
            prompt=cfg.prompt,
            timeout=cfg.timeout_seconds,
        )
    except Exception as exc:
        logger.warning("Could not build OpenAI-compatible captioner: %s", exc)
        if cfg.fail_on_error:
            raise
        return None


def _build_picture_description(cfg: DoclingConfig) -> Any:
    pd = cfg.enrichments.picture_description
    if not pd.enabled:
        return None
    logger.info("Building picture description enricher (backend=%s)", pd.backend.value)
    return {
        CaptioningBackend.OLLAMA:             lambda: _build_ollama_captioner(pd.ollama),
        CaptioningBackend.OPENAI_COMPATIBLE:  lambda: _build_openai_compatible_captioner(pd.openai_compatible),
    }.get(pd.backend, lambda: None)()


# ---------------------------------------------------------------------------
# Device resolver
# ---------------------------------------------------------------------------


def _resolve_device(device: InferenceDevice) -> str:
    if device != InferenceDevice.AUTO:
        return device.value
    try:
        import torch
        if torch.cuda.is_available():
            return "cuda"
        if torch.backends.mps.is_available():
            return "mps"
    except ImportError:
        pass
    return "cpu"


# ---------------------------------------------------------------------------
# Public builder
# ---------------------------------------------------------------------------


class DoclingPipelineBuilder:
    """
    Builds a Haystack ``DoclingConverter`` component from ``DoclingConfig``.

    Usage::

        converter = DoclingPipelineBuilder(settings.docling).build()
        pipeline.add_component("converter", converter)
    """

    def __init__(self, cfg: DoclingConfig) -> None:
        self.cfg = cfg

    def build(self) -> Any:
        """Build a DoclingConverter for the default export mode."""
        try:
            from docling.document_converter import DocumentConverter
            from docling_haystack.converter import DoclingConverter, ExportType as DExportType
        except ImportError as exc:
            raise ImportError(
                "Run: pip install docling docling-haystack"
            ) from exc

        logger.info(
            "Building DoclingConverter | export=%s | ocr=%s | enrichments=[%s]",
            self.cfg.export.type.value,
            self.cfg.pdf.ocr_engine.value,
            self._enrichment_summary(),
        )

        dc = DocumentConverter(format_options=_build_format_options(self.cfg))
        self._attach_enrichments(dc)

        export_map = {
            ExportType.DOC_CHUNKS: DExportType.DOC_CHUNKS,
            ExportType.MARKDOWN:   DExportType.MARKDOWN,
        }
        
        dtype = export_map[self.cfg.export.type]
        md_kwargs = None
        chunker = None

        if dtype == DExportType.MARKDOWN:
            md_kwargs = {"image_mode": self.cfg.export.markdown_options.image_mode}
        elif dtype == DExportType.DOC_CHUNKS:
            # For DOC_CHUNKS, we explicitly build a HierarchicalChunker with 
            # Markdown table serialization enabled.
            try:
                from docling_core.transforms.chunker.hierarchical_chunker import HierarchicalChunker
                chunker = HierarchicalChunker(
                    serializer_provider=self._build_serializer_provider()
                )
            except ImportError:
                logger.warning("Could not import HierarchicalChunker; using docling-haystack default.")

        return DoclingConverter(
            converter=dc,
            export_type=dtype,
            chunker=chunker,
            md_export_kwargs=md_kwargs,
        )

    def build_with_hybrid_chunker(
        self,
        tokenizer: str = "BAAI/bge-small-en-v1.5",
        max_tokens: int = 512,
        merge_peers: bool = True,
    ) -> Any:
        """Build with Docling's HybridChunker embedded (document_aware strategy)."""
        try:
            from docling.document_converter import DocumentConverter
            from docling_haystack.converter import DoclingConverter, ExportType as DExportType
        except ImportError as exc:
            raise ImportError("Run: pip install docling docling-haystack") from exc

        chunker = None
        try:
            from docling_core.transforms.chunker.hybrid_chunker import HybridChunker
            chunker = HybridChunker(
                tokenizer=tokenizer,
                max_tokens=max_tokens,
                merge_peers=merge_peers,
                serializer_provider=self._build_serializer_provider(),
            )
        except ImportError:
            logger.warning(
                "HybridChunker not found — using docling-haystack default chunker. "
                "Run: pip install docling-core"
            )

        dc = DocumentConverter(format_options=_build_format_options(self.cfg))
        self._attach_enrichments(dc)

        return DoclingConverter(
            converter=dc,
            export_type=DExportType.DOC_CHUNKS,
            chunker=chunker,
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _build_serializer_provider(self) -> Any:
        """
        Builds a ChunkingSerializerProvider that uses MarkdownTableSerializer.
        This ensures tables are chunked as Markdown rather than triplet notation.
        """
        try:
            from docling_core.transforms.chunker.hierarchical_chunker import (
                ChunkingDocSerializer,
                ChunkingSerializerProvider,
            )
            from docling_core.transforms.serializer.markdown import MarkdownTableSerializer

            class MDTableSerializerProvider(ChunkingSerializerProvider):
                def get_serializer(self, doc: Any) -> Any:
                    return ChunkingDocSerializer(
                        doc=doc,
                        table_serializer=MarkdownTableSerializer(),
                    )

            return MDTableSerializerProvider()
        except ImportError:
            logger.debug("Docling core serializer components not found; using default.")
            return None

    def _attach_enrichments(self, dc: Any) -> None:
        # NOTE: In Docling 2.x, picture description is attached via PdfPipelineOptions
        # during _build_format_options, so we don't need to do it here.
        # This method now only logs status and handles other enrichments.
        enc = self.cfg.enrichments
        if enc.picture_classification_enabled:
            logger.info("Picture classification enricher: enabled (built-in)")
        if enc.code_understanding_enabled:
            logger.info("Code understanding enricher: enabled")
        if enc.formula_understanding_enabled:
            logger.info("Formula understanding enricher: enabled")

    def _enrichment_summary(self) -> str:
        enc = self.cfg.enrichments
        parts = []
        if enc.picture_description.enabled:
            parts.append(f"caption({enc.picture_description.backend.value})")
        if enc.picture_classification_enabled:
            parts.append("classify")
        if enc.code_understanding_enabled:
            parts.append("code")
        if enc.formula_understanding_enabled:
            parts.append("formula")
        return ", ".join(parts) or "none"