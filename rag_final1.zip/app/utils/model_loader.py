"""
ModelLoader
===========

A thread-safe utility to ensure SentenceTransformer and CrossEncoder models
(and their Haystack component wrappers) are loaded only once and shared
across multiple pipeline instances.
"""

import logging
import threading
from typing import Any, Dict, Type

logger = logging.getLogger(__name__)

class ModelCache:
    """
    Caches Haystack components that wrap heavy local models.
    
    The cache key is derived from the component class and its configuration
    parameters (model name, device, etc.).
    """
    def __init__(self):
        self._cache: Dict[tuple, Any] = {}
        self._lock = threading.Lock()

    def get_component(self, component_cls: Type, **kwargs) -> Any:
        # Create a stable cache key from class and sorted kwargs
        # We convert dicts/lists to tuples to make them hashable if needed
        # but usually these are strings/bools/ints.
        sorted_items = []
        for k, v in sorted(kwargs.items()):
            if isinstance(v, list):
                sorted_items.append((k, tuple(v)))
            elif isinstance(v, dict):
                sorted_items.append((k, tuple(sorted(v.items()))))
            else:
                try:
                    hash(v)
                    sorted_items.append((k, v))
                except TypeError:
                    sorted_items.append((k, str(v)))
        
        key = (component_cls, tuple(sorted_items))
        
        with self._lock:
            if key not in self._cache:
                logger.info(
                    "ModelCache: loading new instance of %s with model '%s' ...",
                    component_cls.__name__, kwargs.get("model")
                )
                self._cache[key] = component_cls(**kwargs)
            else:
                logger.debug(
                    "ModelCache: reusing cached instance of %s for model '%s'.",
                    component_cls.__name__, kwargs.get("model")
                )
            return self._cache[key]

# Global singleton
_model_cache = ModelCache()

def get_cached_component(component_cls: Type, **kwargs) -> Any:
    """
    Public API to get a cached component.
    
    Usage::
        embedder = get_cached_component(SentenceTransformersTextEmbedder, model="...", device="...")
    """
    return _model_cache.get_component(component_cls, **kwargs)
