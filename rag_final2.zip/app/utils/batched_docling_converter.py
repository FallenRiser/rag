"""
BatchedDoclingConverter
=======================

Custom Haystack component that processes large PDFs through Docling in
small page-range batches to prevent out-of-memory (std::bad_alloc) errors.

How it works:
  1. Split the input PDF into temporary mini-PDFs of N pages each (default 15)
  2. Run Docling's DocumentConverter on each mini-PDF independently
  3. Merge all output Haystack Documents, adjusting page numbers
  4. Release memory (gc.collect) between batches

This preserves Docling's structural extraction (headings, tables as Markdown,
page metadata, bounding boxes) while keeping peak memory bounded.

The converter always exports Markdown text — downstream Haystack splitters
(HierarchicalDocumentSplitter, RecursiveDocumentSplitter, etc.) handle chunking.
"""

from __future__ import annotations

import gc
import tempfile
from pathlib import Path
from typing import Any, List, Optional, Union

from loguru import logger

logger = logger.bind(submodule=__name__)


def _split_pdf_into_batches(
    pdf_path: str | Path, batch_size: int, output_dir: str
) -> list[tuple[Path, int]]:
    """
    Split a PDF into multiple smaller PDFs of ``batch_size`` pages each.

    Returns a list of (temp_pdf_path, start_page_0indexed) tuples.
    """
    from pypdf import PdfReader, PdfWriter

    reader = PdfReader(str(pdf_path))
    total_pages = len(reader.pages)
    logger.info(
        "Splitting {} ({} pages) into batches of {}",
        Path(pdf_path).name, total_pages, batch_size,
    )

    batches: list[tuple[Path, int]] = []
    for start in range(0, total_pages, batch_size):
        end = min(start + batch_size, total_pages)
        writer = PdfWriter()
        for page_idx in range(start, end):
            writer.add_page(reader.pages[page_idx])

        batch_path = Path(output_dir) / f"batch_{start:04d}_{end:04d}.pdf"
        with open(batch_path, "wb") as f:
            writer.write(f)
        batches.append((batch_path, start))
        logger.debug("  Batch: pages {}–{} → {}", start + 1, end, batch_path.name)

    return batches


try:
    from haystack import Document, component

    @component
    class BatchedDoclingConverter:
        """
        Haystack component that converts PDFs via Docling in page batches.

        Drop-in replacement for ``DoclingConverter`` in the indexing pipeline.
        Produces one Haystack Document per page batch containing Markdown text
        with Docling's structural extraction (headings, tables, page metadata).
        Downstream Haystack splitters handle the actual chunking.

        Parameters
        ----------
        batch_size : int
            Number of pages per batch. Lower = less memory, more overhead.
            Default 15 works on machines with 8 GB RAM.
        docling_config : Any
            ``DoclingConfig`` instance for building the Docling converter.
        export_type : str
            "doc_chunks" or "markdown" — currently always exports as markdown
            so downstream Haystack splitters can chunk properly.
        """

        def __init__(
            self,
            docling_config: Any = None,
            batch_size: int = 15,
            export_type: str = "doc_chunks",
        ):
            self.batch_size = batch_size
            self.docling_config = docling_config
            self.export_type = export_type

        @component.output_types(documents=List[Document])
        def run(
            self,
            sources: List[Union[str, Path]],
            meta: Optional[Union[dict, List[dict]]] = None,
        ) -> dict:
            """
            Convert PDF sources in page batches.

            Parameters
            ----------
            sources : list of str/Path
                Paths to PDF files (or other supported formats).
            meta : dict or list of dict, optional
                Metadata to attach. The ingest endpoint sends a single dict;
                other callers may send a list (one per source).
            """
            # Normalize meta to a list matching sources length
            if meta is None:
                meta_list = [{} for _ in sources]
            elif isinstance(meta, dict):
                meta_list = [meta for _ in sources]
            else:
                meta_list = meta

            all_documents: list[Document] = []

            for src_idx, source in enumerate(sources):
                source_path = Path(source)
                src_meta = meta_list[src_idx] if src_idx < len(meta_list) else {}

                if source_path.suffix.lower() != ".pdf":
                    # Non-PDF files: pass through to Docling directly
                    docs = self._convert_single(source_path, src_meta)
                    all_documents.extend(docs)
                    continue

                # PDF: split into batches
                docs = self._convert_pdf_batched(source_path, src_meta)
                all_documents.extend(docs)

            logger.info(
                "BatchedDoclingConverter: {} total documents from {} source(s)",
                len(all_documents), len(sources),
            )
            return {"documents": all_documents}

        def _convert_pdf_batched(
            self, pdf_path: Path, src_meta: dict
        ) -> list[Document]:
            """Split a PDF into batches and convert each through Docling."""
            results: list[Document] = []

            with tempfile.TemporaryDirectory() as tmpdir:
                batches = _split_pdf_into_batches(pdf_path, self.batch_size, tmpdir)

                for batch_idx, (batch_path, page_offset) in enumerate(batches):
                    logger.info(
                        "Processing batch {}/{} (pages {}–{}) of {}",
                        batch_idx + 1,
                        len(batches),
                        page_offset + 1,
                        page_offset + self.batch_size,
                        pdf_path.name,
                    )

                    try:
                        docs = self._convert_single(batch_path, src_meta)

                        # Fix page numbers and source file name
                        for doc in docs:
                            if doc.meta.get("page_number") is not None:
                                doc.meta["page_number"] += page_offset
                            if "dl_meta" in doc.meta:
                                dl = doc.meta["dl_meta"]
                                if isinstance(dl, dict) and "page_no" in dl:
                                    dl["page_no"] += page_offset
                            # Always set the original source file name
                            doc.meta["source_file"] = pdf_path.name
                            doc.meta["batch_page_offset"] = page_offset

                        results.extend(docs)
                    except Exception:
                        logger.exception(
                            "Batch {} failed for {} (pages {}–{}) — skipping",
                            batch_idx + 1,
                            pdf_path.name,
                            page_offset + 1,
                            page_offset + self.batch_size,
                        )

                    # Force memory release between batches
                    gc.collect()

            logger.info(
                "PDF {}: {} documents from {} batches",
                pdf_path.name, len(results), len(batches),
            )
            return results

        def _convert_single(self, file_path: Path, src_meta: dict) -> list[Document]:
            """
            Run a single file through Docling and return Haystack Documents.

            Always exports as Markdown so downstream Haystack splitters
            (HierarchicalDocumentSplitter etc.) can do proper chunking.
            """
            from docling.document_converter import DocumentConverter

            # Build a fresh converter for each batch to avoid accumulated memory
            from app.utils.docling_pipeline import _build_format_options

            converter = DocumentConverter(
                format_options=_build_format_options(self.docling_config)
            )

            # Convert
            result = converter.convert(str(file_path))

            # Export as Markdown — preserves tables, headings, structure
            md_text = result.document.export_to_markdown()

            doc = Document(
                content=md_text,
                meta={
                    **src_meta,
                    "source_file": file_path.name,
                },
            )

            # Explicit cleanup
            del converter, result
            gc.collect()

            return [doc]

except ImportError:
    # Stub when Haystack not installed
    class BatchedDoclingConverter:  # type: ignore[no-redef]
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            raise ImportError("Haystack is required: pip install haystack-ai")
