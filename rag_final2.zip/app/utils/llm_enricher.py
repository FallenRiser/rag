"""
Optional LLM Enrichment wrapper for Haystack's LLMMetadataExtractor.
"""

from typing import Any

from haystack import Document, component
from haystack.components.extractors.llm_metadata_extractor import LLMMetadataExtractor
from haystack.components.generators.chat import OpenAIChatGenerator
from haystack_integrations.components.generators.ollama import OllamaChatGenerator

from config.settings import AppSettings
from app.utils.model_loader import get_cached_component

@component
class OptionalLLMEnricher:
    """
    Wraps LLMMetadataExtractor to allow dynamic toggling at request time.
    """
    def __init__(self, extractor: LLMMetadataExtractor | None):
        self.extractor = extractor

    @component.output_types(documents=list[Document])
    def run(self, documents: list[Document], enabled: bool = True) -> dict[str, Any]:
        if not self.extractor or not enabled or not documents:
            return {"documents": documents}
        
        result = self.extractor.run(documents=documents)
        # Log failed documents if any?
        return {"documents": result.get("documents", documents)}


def build_llm_metadata_extractor(settings: AppSettings) -> LLMMetadataExtractor | None:
    """Builds the core LLMMetadataExtractor based on config."""
    cfg = settings.docling.enrichments.llm_metadata
    if not cfg.enabled:
        return None

    gen_cfg = settings.query.generator
    chat_generator = None

    if gen_cfg.backend.value == "openai":
        from haystack.utils import Secret
        import os
        api_key = os.getenv(gen_cfg.openai.api_key_env)
        
        # We enforce JSON output schema for reliable extraction
        json_schema = {
            "name": "metadata_extraction",
            "schema": {
                "type": "object",
                "properties": {
                    key: {"type": "array", "items": {"type": "object"}} if key == "entities" else {"type": "string"}
                    for key in cfg.expected_keys
                },
                "required": cfg.expected_keys,
                "additionalProperties": False,
            }
        }
        
        kwargs = {
            "model": gen_cfg.openai.model,
            "api_key": Secret.from_token(api_key) if api_key else None,
            "api_base_url": gen_cfg.openai.base_url,
            "generation_kwargs": {
                "temperature": 0.0,  # Zero for extraction
                "response_format": {
                    "type": "json_schema",
                    "json_schema": json_schema
                }
            }
        }
        
        chat_generator = get_cached_component(OpenAIChatGenerator, **kwargs)
        
    elif gen_cfg.backend.value == "ollama":
        kwargs = {
            "model": gen_cfg.ollama.model,
            "url": f"{gen_cfg.ollama.base_url.rstrip('/')}/api/chat",
            "generation_kwargs": {
                "temperature": 0.0,
                "format": "json"
            }
        }
        chat_generator = get_cached_component(OllamaChatGenerator, **kwargs)

    if not chat_generator:
        return None

    return LLMMetadataExtractor(
        prompt=cfg.prompt,
        chat_generator=chat_generator,
        expected_keys=cfg.expected_keys,
        raise_on_failure=False
    )
