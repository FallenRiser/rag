"""Backward-compatibility shim — logging has moved to app.observability.logging."""
from app.observability.logging import setup_logging  # noqa: F401
