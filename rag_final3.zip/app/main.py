"""
RAG Pipeline — FastAPI application factory.

Startup sequence
----------------
1. Load + validate YAML configs (AppSettings).
2. Set up Loguru logging + rotating file sinks.
3. Initialise MLflow tracing (optional).
4. Register default pipeline config with PipelineRegistry (lazy build on
   first request).
5. Rebuild DocumentVersionRegistry from existing store metadata so a server
   restart doesn't lose version history.

OpenAPI / Swagger UI fix
------------------------
Pydantic v2 generates ``contentMediaType: application/octet-stream`` for
``UploadFile`` fields instead of the ``format: binary`` that Swagger UI
requires to render a file-picker widget. The ``custom_openapi()`` function
patches this post-generation so the Swagger UI shows correct file pickers.
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import AsyncGenerator

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from loguru import logger

logger = logger.bind(submodule=__name__)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """FastAPI lifespan hook: startup → yield → shutdown."""
    # ── Startup ─────────────────────────────────────────────────────────
    import os
    from pathlib import Path
    
    # Configure local models directories
    models_dir = Path("models").resolve()
    os.environ["HF_HOME"] = str(models_dir / "hf")

    # Only force DOCLING_ARTIFACTS_PATH if the directory actually has the core models.
    # If empty, we let Docling use its default cache to allow automatic downloads.
    docling_artifacts = models_dir / "docling"
    if (docling_artifacts / "model.safetensors").exists():
        os.environ["DOCLING_ARTIFACTS_PATH"] = str(docling_artifacts)
        logger.info("Docling using local artifacts at: {}", docling_artifacts)
    else:
        logger.info("Local Docling models not found; using default cache (automatic download enabled).")

    from config.settings import get_settings
    from app.utils.pipeline_registry import registry
    from app.observability.tracing import setup_tracing
    from app.observability.logging import setup_logging

    settings = get_settings()

    # Logging must be initialised before everything else
    setup_logging(log_level=settings.log_level)
    setup_tracing(settings)

    # Register default pipeline configuration
    registry.register(settings, name="default")

    # Register a fallback variant with HyDE disabled for runtime toggling
    settings_no_hyde = settings.model_copy(deep=True)
    settings_no_hyde.query.hyde.enabled = False
    registry.register(settings_no_hyde, name="default_no_hyde")

    logger.info(
        "RAG Pipeline started | env={} | chunking={} | embedding={} | store={}",
        settings.env,
        settings.chunking.strategy.value,
        settings.embedding.provider.value,
        settings.document_store.backend.value,
    )
    logger.debug(f"Registered pipelines: {registry.registered_names()}")

    # Rebuild version history from store so restarts don't lose tracking.
    try:
        from app.utils.document_version_registry import version_registry
        idx_pipeline = registry.get_indexing("default")
        store = idx_pipeline.get_component("writer").document_store
        n = version_registry.rebuild_from_store(store)
        logger.info("Version registry: {} record(s) restored from store.", n)

        # Rebuild persistent BM25 index if enabled and empty.
        bm25_cfg = settings.document_store.bm25_persistence
        if bm25_cfg.enabled and bm25_cfg.auto_rebuild_on_startup:
            from app.repositories.bm25_repository import get_bm25_manager
            bm25_manager = get_bm25_manager(persist_path=bm25_cfg.persist_path)
            if bm25_manager.document_count() == 0:
                logger.info("BM25 index is empty — rebuilding from primary store…")
                n_bm25 = bm25_manager.rebuild_from_primary_store(store)
                logger.info("BM25 index rebuilt: {} document(s) synced.", n_bm25)

    except Exception as exc:
        logger.warning(
            "Could not rebuild registries from store: {} — "
            "they will repopulate on new ingests.",
            exc,
        )

    yield

    # ── Shutdown ─────────────────────────────────────────────────────────
    logger.info("RAG Pipeline shutting down.")


def _patch_upload_schema(node: object) -> None:
    """
    Recursively replace ``contentMediaType: application/octet-stream`` with
    ``format: binary`` so Swagger UI renders file-picker buttons.

    Root cause: Pydantic v2 changed the JSON schema representation of
    UploadFile.  FastAPI has not yet aligned its schema generation.
    """
    if isinstance(node, dict):
        if node.get("contentMediaType") == "application/octet-stream":
            node.pop("contentMediaType")
            node["format"] = "binary"
        for v in node.values():
            _patch_upload_schema(v)
    elif isinstance(node, list):
        for item in node:
            _patch_upload_schema(item)


def create_app() -> FastAPI:
    app = FastAPI(
        title="RAG Pipeline API",
        description=(
            "Production-grade document extraction and RAG ingestion pipeline "
            "built on Haystack 2.x + Docling. "
            "PDF · DOCX · HTML · PPTX · images | OCR | table extraction | "
            "LLM image captioning | 12 chunking strategies | "
            "user isolation | document versioning."
        ),
        version="0.1.0",
        lifespan=lifespan,
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
    )

    # ── CORS ─────────────────────────────────────────────────────────────
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],          # tighten in production
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ── Routers ───────────────────────────────────────────────────────────
    from app.routes.v1 import v1_router
    app.include_router(v1_router)

    # ── Custom OpenAPI: fix UploadFile schema for Swagger file pickers ───
    from fastapi.openapi.utils import get_openapi

    def custom_openapi() -> dict:
        if app.openapi_schema:
            return app.openapi_schema
        schema = get_openapi(
            title=app.title,
            version=app.version,
            description=app.description,
            routes=app.routes,
        )
        _patch_upload_schema(schema)
        app.openapi_schema = schema
        return schema

    app.openapi = custom_openapi  # type: ignore[method-assign]

    # ── Root redirect ─────────────────────────────────────────────────────
    @app.get("/", include_in_schema=False)
    async def root() -> dict:
        return {"service": "rag-pipeline", "docs": "/docs", "health": "/v1/health"}

    return app


app = create_app()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
