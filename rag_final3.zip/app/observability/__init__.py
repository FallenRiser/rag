"""
Observability package — logging, tracing, and metrics.

Provides:
    - ``logging`` — Centralised Loguru setup with rotating file sinks.
    - ``tracing`` — MLflow GenAI tracing integration.
"""
