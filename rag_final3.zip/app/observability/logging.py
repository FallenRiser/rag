"""
Centralised Loguru logging configuration.

Provides:
    - ``setup_logging(log_level, log_dir)`` — call once at startup to configure
      sinks (stderr + rotating file) and intercept stdlib ``logging``.

All other modules should use loguru's ``bind`` directly::

    from loguru import logger

    logger = logger.bind(submodule=__name__)
    logger.info("Hello from this module")

File logs are written to ``<project>/app/logs/rag_pipeline.log`` with daily
rotation (7-day retention).
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path

from loguru import logger as _loguru_logger


# ---------------------------------------------------------------------------
# Stdlib interception — route all ``logging.*`` calls through Loguru
# ---------------------------------------------------------------------------

class _InterceptHandler(logging.Handler):
    """Bridges stdlib ``logging`` → Loguru so third-party libraries (Haystack,
    uvicorn, httpx, etc.) automatically flow into the same sinks."""

    def emit(self, record: logging.LogRecord) -> None:
        # Map stdlib level name → Loguru level
        try:
            level = _loguru_logger.level(record.levelname).name
        except ValueError:
            level = record.levelno

        # Walk the call stack to find the real caller
        frame, depth = logging.currentframe(), 2
        while frame and frame.f_code.co_filename == logging.__file__:
            frame = frame.f_back
            depth += 1

        _loguru_logger.bind(submodule=record.name).opt(depth=depth, exception=record.exc_info).log(
            level, record.getMessage()
        )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

_DEFAULT_LOG_DIR = Path(__file__).resolve().parent.parent / "logs"

_FORMAT = (
    "<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | "
    "<level>{level: <8}</level> | "
    "<cyan>{extra[submodule]}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> — "
    "<level>{message}</level>"
)


def setup_logging(
    log_level: str = "INFO",
    log_dir: Path | str | None = None,
) -> None:
    """Initialise Loguru sinks and intercept stdlib logging.

    Args:
        log_level: Minimum level for all sinks (DEBUG, INFO, WARNING, …).
        log_dir:   Directory for rotating log files. Defaults to ``app/logs/``.
    """
    log_dir = Path(log_dir) if log_dir else _DEFAULT_LOG_DIR
    log_dir.mkdir(parents=True, exist_ok=True)

    level = log_level.upper()

    # Reset Loguru — remove default stderr sink
    _loguru_logger.remove()
    _loguru_logger.configure(extra={"submodule": "unknown"})

    # Sink 1: stderr (coloured, human-readable)
    _loguru_logger.add(
        sys.stderr,
        level=level,
        format=_FORMAT,
        enqueue=True,
        backtrace=True,
        diagnose=False,
    )

    # Sink 2: rotating file
    log_file = log_dir / "rag_pipeline.log"
    _loguru_logger.add(
        str(log_file),
        level=level,
        format=_FORMAT,
        rotation="00:00",      # new file every midnight
        retention="7 days",
        compression="zip",
        enqueue=True,
        backtrace=True,
        diagnose=False,
    )

    # Intercept all stdlib loggers → Loguru
    logging.basicConfig(handlers=[_InterceptHandler()], level=0, force=True)

    # Quieten noisy third-party loggers
    for noisy in ("httpx", "httpcore", "watchfiles", "multipart"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    _loguru_logger.bind(submodule=__name__).info(
        "Logging initialised — level={} | file={}",
        level,
        log_file,
    )
