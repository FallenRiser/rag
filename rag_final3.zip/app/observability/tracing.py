"""
Observability setup — MLflow GenAI Traces.

Call ``setup_tracing(settings)`` once during FastAPI lifespan startup
**after** ``setup_logging()`` has already been called.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from loguru import logger

if TYPE_CHECKING:
    from config.settings import AppSettings

logger = logger.bind(submodule=__name__)


def setup_tracing(settings: "AppSettings") -> None:
    """Initialise MLflow GenAI tracing.

    Loguru logging is configured separately via ``app.logging.setup_logging()``.
    This function only handles MLflow experiment + autologging setup.

    Args:
        settings: Application settings containing MLflow configuration.
    """
    try:
        import mlflow

        mlflow.set_tracking_uri(settings.mlflow_tracking_uri)
        logger.info("MLflow tracking URI set: {}", mlflow.get_tracking_uri())

        mlflow.set_experiment(settings.mlflow_experiment_name)
        logger.info("MLflow experiment set: {}", settings.mlflow_experiment_name)

        # Enable Haystack autologging for GenAI traces
        try:
            import mlflow.haystack
            mlflow.haystack.autolog(log_traces=True)
            logger.info("Haystack autologging enabled (log_traces=True).")
        except (ImportError, AttributeError) as exc:
            logger.warning("mlflow.haystack.autolog() not available: {}", exc)

        # Also enable tracing for any OpenAI calls if available
        try:
            if hasattr(mlflow, "openai"):
                mlflow.openai.autolog()
                logger.info("OpenAI autologging enabled.")
        except Exception:
            pass

        logger.info(
            "MLflow tracing enabled → {} | Experiment: {}",
            mlflow.get_tracking_uri(),
            settings.mlflow_experiment_name,
        )
    except ImportError as exc:
        logger.warning(
            "MLflow package not installed; tracing disabled. "
            "Run: pip install mlflow  |  Error: {}",
            exc,
        )
