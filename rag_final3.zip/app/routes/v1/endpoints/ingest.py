"""
POST /v1/ingest           — Upload files (multipart/form-data).
POST /v1/ingest/sync      — Upload files (synchronous, blocking).
GET  /v1/ingest/jobs/{id} — Poll async job status.

File upload
-----------
Send files as standard multipart/form-data — exactly like a browser
<input type="file"> form. Do NOT base64-encode.

  curl -X POST http://localhost:8000/v1/ingest \\
       -H "X-User-ID: alice-001" \\
       -F "files=@report.pdf" \\
       -F "files=@slides.pptx" \\
       -F "pipeline_name=default" \\
       -F "version_note=Q3 reports"
"""

from __future__ import annotations

import shutil
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional

from fastapi import (
    APIRouter,
    BackgroundTasks,
    Depends,
    File,
    Form,
    HTTPException,
    UploadFile,
    status,
)

from app.dependencies import get_app_settings, get_registry
from loguru import logger
from app.schemas.ingest import (
    FileIngestResult,
    IngestJobDetail,
    IngestResponse,
    JobStatus,
)
from app.services.ingestion_service import run_ingestion_job
from config.settings import AppSettings
from app.utils.pipeline_registry import PipelineRegistry
from app.utils.user_context import UserContext, require_user

logger = logger.bind(submodule=__name__)

router = APIRouter(prefix="/ingest", tags=["ingestion"])

# In-process job store — swap for Redis / DB in multi-process deployments.
_jobs: dict[str, IngestJobDetail] = {}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _prepare_upload(
    files: list[UploadFile], tmp_dir: str
) -> list[dict]:
    """Read uploaded files and write them to a temp directory.

    Returns:
        List of dicts with keys ``path``, ``name``, ``raw_bytes``.
    """
    entries: list[dict] = []
    for upload in files:
        raw_bytes = await upload.read()
        source_name = Path(upload.filename or "upload").name
        dest = Path(tmp_dir) / source_name
        dest.write_bytes(raw_bytes)
        entries.append({"path": dest, "name": source_name, "raw_bytes": raw_bytes})
    return entries


def _validate_pipeline(
    pipeline_name: str, registry: PipelineRegistry
) -> None:
    """Raise 404 if the requested pipeline is not registered."""
    if pipeline_name not in registry.registered_names():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                f"Pipeline '{pipeline_name}' not registered. "
                f"Available: {registry.registered_names()}"
            ),
        )


def _validate_files(files: list[UploadFile]) -> None:
    """Raise 422 if no files provided."""
    if not files:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="At least one file must be provided.",
        )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post(
    "",
    response_model=IngestResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Ingest documents",
    description=(
        "Upload one or more documents as multipart/form-data. "
        "Accepts PDF, DOCX, HTML, PPTX, and image files. "
        "Identical content (SHA-256 dedup) is skipped automatically. "
        "Each changed re-upload creates a new version."
    ),
)
async def ingest_documents(
    background_tasks: BackgroundTasks,
    files: List[UploadFile] = File(
        description="Documents to ingest — PDF, DOCX, HTML, PPTX, images"
    ),
    pipeline_name: str = Form(default="default"),
    version_note: str = Form(
        default="",
        description="Optional human-readable note stored with this version",
    ),
    enable_llm_enrichment: Optional[bool] = Form(
        default=None,
        description="Override global LLM enrichment config (True/False)",
    ),
    ctx: UserContext = Depends(require_user),
    registry: PipelineRegistry = Depends(get_registry),
    settings: AppSettings = Depends(get_app_settings),
) -> IngestResponse:
    _validate_files(files)
    _validate_pipeline(pipeline_name, registry)

    job_id = str(uuid.uuid4())
    tmp_dir = tempfile.mkdtemp(prefix=f"rag_{job_id}_")
    file_entries = await _prepare_upload(files, tmp_dir)

    job = IngestJobDetail(
        job_id=job_id,
        status=JobStatus.PENDING,
        pipeline_name=pipeline_name,
        user_id=ctx.user_id,
        created_at=datetime.now(tz=timezone.utc),
        files_received=len(file_entries),
    )
    _jobs[job_id] = job

    background_tasks.add_task(
        run_ingestion_job,
        job=job,
        user_ctx=ctx,
        tmp_dir=tmp_dir,
        file_entries=file_entries,
        pipeline_name=pipeline_name,
        version_note=version_note,
        enable_llm_enrichment=enable_llm_enrichment,
        registry=registry,
    )

    logger.info(
        "Job {} queued | user={} | files={} | pipeline={}",
        job_id, ctx.user_id, len(file_entries), pipeline_name,
    )

    return IngestResponse(
        job_id=job_id,
        status=JobStatus.PENDING,
        pipeline_name=pipeline_name,
        files_received=len(file_entries),
        message=f"Job {job_id} queued. Poll GET /v1/ingest/jobs/{job_id}.",
    )


@router.post(
    "/sync",
    response_model=IngestJobDetail,
    status_code=status.HTTP_200_OK,
    summary="Ingest documents (Synchronous)",
    description=(
        "Upload documents and wait for processing to complete. "
        "Returns the full job detail including chunk counts and version numbers. "
        "NOTE: Large files or VLM enrichments may cause timeouts."
    ),
)
async def ingest_documents_sync(
    files: List[UploadFile] = File(
        description="Documents to ingest — PDF, DOCX, HTML, PPTX, images"
    ),
    pipeline_name: str = Form(default="default"),
    version_note: str = Form(
        default="",
        description="Optional human-readable note stored with this version",
    ),
    enable_llm_enrichment: Optional[bool] = Form(
        default=None,
        description="Override global LLM enrichment config (True/False)",
    ),
    ctx: UserContext = Depends(require_user),
    registry: PipelineRegistry = Depends(get_registry),
    settings: AppSettings = Depends(get_app_settings),
) -> IngestJobDetail:
    """Block until ingestion is fully complete."""
    _validate_files(files)

    job_id = str(uuid.uuid4())
    tmp_dir = tempfile.mkdtemp(prefix=f"rag_sync_{job_id}_")

    try:
        file_entries = await _prepare_upload(files, tmp_dir)

        job = IngestJobDetail(
            job_id=job_id,
            status=JobStatus.PENDING,
            pipeline_name=pipeline_name,
            user_id=ctx.user_id,
            created_at=datetime.now(tz=timezone.utc),
            files_received=len(file_entries),
        )
        _jobs[job_id] = job

        import anyio

        await anyio.to_thread.run_sync(
            lambda: run_ingestion_job(
                job=job,
                user_ctx=ctx,
                tmp_dir=tmp_dir,
                file_entries=file_entries,
                pipeline_name=pipeline_name,
                version_note=version_note,
                enable_llm_enrichment=enable_llm_enrichment,
                registry=registry,
            )
        )

        return _jobs[job_id]

    except Exception as exc:
        shutil.rmtree(tmp_dir, ignore_errors=True)
        logger.error("Sync ingestion failed: {}", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=str(exc))


@router.get(
    "/jobs/{job_id}",
    response_model=IngestJobDetail,
    summary="Poll ingestion job status",
)
async def get_job_status(
    job_id: str,
    ctx: UserContext = Depends(require_user),
) -> IngestJobDetail:
    job = _jobs.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail=f"Job '{job_id}' not found.")
    if job.user_id != ctx.user_id:
        raise HTTPException(status_code=403, detail="Access denied.")
    return job
