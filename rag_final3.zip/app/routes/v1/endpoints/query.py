"""
POST /v1/query   — RAG: embed query → retrieve → rerank → generate answer.
POST /v1/search  — Retrieval-only (no LLM): returns ranked source documents.

Streaming
---------
When query.stream=true, the endpoint returns a Server-Sent Events (SSE)
stream. Each event carries a single token delta from the generator.
The final event contains the complete answer and sources under
data: [DONE].
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import StreamingResponse

from app.dependencies import get_app_settings, get_registry
from loguru import logger
from app.schemas.query import (
    QueryRequest,
    QueryResponse,
    SearchRequest,
    SearchResponse,
)
from app.services.query_service import (
    build_base_filters,
    build_pipeline_input,
    build_streaming_response,
    extract_auto_filters,
    format_search_results,
    parse_query_result,
    resolve_pipeline_name,
)
from app.services.retrieval_service import (
    retrieve_single_query,
    retrieve_with_multi_query,
)
from config.settings import AppSettings
from app.utils.pipeline_registry import PipelineRegistry
from app.utils.user_context import UserContext, require_user

logger = logger.bind(submodule=__name__)

router = APIRouter(tags=["query"])


# ---------------------------------------------------------------------------
# POST /v1/query
# ---------------------------------------------------------------------------


@router.post(
    "/query",
    response_model=QueryResponse,
    summary="RAG question answering",
    description=(
        "Performs a full Retrieval-Augmented Generation (RAG) flow. "
        "Includes query expansion (HyDE), retrieval with user isolation, "
        "context truncation, and LLM-based answer generation."
    ),
)
async def query(
    request: QueryRequest,
    registry: PipelineRegistry = Depends(get_registry),
    settings: AppSettings = Depends(get_app_settings),
    ctx: UserContext = Depends(require_user),
):
    """Main RAG query endpoint — standard and streaming responses."""
    resolved_name = resolve_pipeline_name(request, settings, registry)
    _validate_pipeline(resolved_name, registry)

    if request.stream:
        return _build_sse_response(request, registry, ctx, resolved_name)

    return await _run_query(request, registry, settings, ctx, resolved_name)


async def _run_query(
    request: QueryRequest,
    registry: PipelineRegistry,
    settings: AppSettings,
    ctx: UserContext,
    pipeline_name: str,
) -> QueryResponse:
    """Execute a non-streaming RAG pipeline."""
    pipeline = registry.get_query(pipeline_name)
    pipeline_settings = registry.get_settings(pipeline_name)

    from app.utils.query_pipeline import QueryPipelineBuilder
    builder = QueryPipelineBuilder(pipeline_settings)

    # Optional auto-filter extraction
    auto_filter_haystack = None
    if getattr(request, "auto_filter", False):
        logger.info("Auto-filter enabled — extracting entities from query…")
        auto_filter_haystack = await extract_auto_filters(request.query, builder)

    # Check multi-query toggle
    mq_cfg = pipeline_settings.query.multi_query
    use_mq = (
        request.enable_multi_query
        if request.enable_multi_query is not None
        else mq_cfg.enabled
    )

    isolation_filter = build_base_filters(
        request, pipeline_settings, ctx, auto_filter_haystack
    )

    if use_mq:
        logger.info("Multi-Query enabled for RAG query: '{}'", request.query)
        idx_pipeline = registry.get_indexing(pipeline_name)
        store = idx_pipeline.get_component("writer").document_store

        docs = await retrieve_with_multi_query(
            request, builder, store, isolation_filter
        )

        gen_pipeline = builder.build_generation_only()
        run_input = {
            "context_truncator": {"documents": docs},
            "prompt_builder": {"query": request.query},
            "answer_builder": {"query": request.query},
        }

        try:
            output = gen_pipeline.run(run_input)
        except Exception as exc:
            logger.error("Generation pipeline failed: {}", exc, exc_info=True)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Multi-Query generation pipeline failed: {exc}",
            )
    else:
        run_input = build_pipeline_input(
            request, pipeline_settings, ctx, pipeline, isolation_filter
        )
        logger.info(
            "Executing RAG pipeline '{}' | Query: '{}'",
            pipeline_name, request.query,
        )

        try:
            output = pipeline.run(run_input)
        except Exception as exc:
            logger.error("Pipeline execution failed: {}", exc, exc_info=True)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Query pipeline failed: {exc}",
            )

    response = parse_query_result(request, output, settings)
    logger.info(
        "RAG complete | Answer length: {} | Sources: {}",
        len(response.answer), len(response.sources),
    )
    return response


def _build_sse_response(
    request: QueryRequest,
    registry: PipelineRegistry,
    ctx: UserContext,
    pipeline_name: str,
) -> StreamingResponse:
    """Wrap the streaming service into a FastAPI StreamingResponse."""
    result = build_streaming_response(request, registry, ctx, pipeline_name)
    return StreamingResponse(
        result["event_generator"](),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


# ---------------------------------------------------------------------------
# POST /v1/search  (retrieval only — no LLM)
# ---------------------------------------------------------------------------


@router.post(
    "/search",
    response_model=SearchResponse,
    summary="Retrieval-only semantic / keyword search",
    description=(
        "Performs a direct search against the document store without "
        "invoking an LLM. Useful for search-only interfaces or debugging."
    ),
)
async def search(
    request: SearchRequest,
    registry: PipelineRegistry = Depends(get_registry),
    settings: AppSettings = Depends(get_app_settings),
    ctx: UserContext = Depends(require_user),
) -> SearchResponse:
    """Retrieval-only endpoint — no LLM generation."""
    _validate_pipeline(request.pipeline_name, registry)
    logger.info(
        "Search request | Type: {} | Query: '{}' | top_k: {}",
        request.search_type, request.query, request.top_k,
    )

    idx_pipeline = registry.get_indexing(request.pipeline_name)
    store = idx_pipeline.get_component("writer").document_store

    # Build isolation filter
    user_isolation_filter = {
        "field": "meta.user_id",
        "operator": "==",
        "value": ctx.user_id,
    }
    if request.filters is not None:
        isolation_filter = {
            "operator": "AND",
            "conditions": [
                user_isolation_filter,
                request.filters.to_haystack(ctx.user_id),
            ],
        }
    else:
        isolation_filter = user_isolation_filter

    try:
        from app.utils.query_pipeline import QueryPipelineBuilder
        builder = QueryPipelineBuilder(settings)

        mq_cfg = settings.query.multi_query
        use_mq = (
            request.enable_multi_query
            if request.enable_multi_query is not None
            else mq_cfg.enabled
        )

        if use_mq:
            docs = await retrieve_with_multi_query(
                request, builder, store, isolation_filter
            )
        else:
            docs = await retrieve_single_query(
                request.query, request, builder, store, isolation_filter
            )

        logger.info("Search retrieval complete: {} documents.", len(docs))

    except Exception as exc:
        logger.error("Search error: {}", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(exc),
        )

    results = format_search_results(docs)

    return SearchResponse(
        query=request.query,
        results=results,
        total=len(results),
        search_type=request.search_type,
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _validate_pipeline(
    pipeline_name: str, registry: PipelineRegistry
) -> None:
    """Verify that a pipeline name is registered.

    Raises:
        HTTPException: 404 if the pipeline name is unknown.
    """
    if pipeline_name not in registry.registered_names():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                f"Pipeline '{pipeline_name}' is not registered. "
                f"Available: {registry.registered_names()}"
            ),
        )
