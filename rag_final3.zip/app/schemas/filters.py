"""
User-friendly filter system for query and search endpoints.
Provides MongoDB-style operators that automatically translate to Haystack format.
"""

from __future__ import annotations

from typing import Any, Dict, List, Union

from pydantic import BaseModel, ConfigDict, Field, field_validator


class SimpleFilter(BaseModel):
    """
    User-friendly filter that uses MongoDB-style operators.

    Supported operators:
    - $eq: equals (default)
    - $ne: not equals
    - $gt: greater than
    - $gte: greater than or equal
    - $lt: less than
    - $lte: less than or equal
    - $in: in array/list
    - $and: logical AND (array of conditions)
    - $or: logical OR (array of conditions)

    Example usage:
    # Search in specific file
    {"source_name": "report.pdf"}

    # Range query
    {"page_number": {"$gte": 1, "$lte": 10}}

    # OR query
    {"source_name": {"$in": ["report1.pdf", "report2.pdf"]}}

    # Complex AND
    {"$and": [
        {"source_name": "report.pdf"},
        {"is_table": true}
    ]}
    """

    model_config = ConfigDict(extra="allow")  # Allow any field names (they represent metadata fields)

    @field_validator('*', mode='before')
    @classmethod
    def validate_operators(cls, v: Any, info) -> Any:
        """Validate that operator values are properly formatted."""
        field_name = info.field_name

        # Skip if not a dict (e.g., simple string/number value)
        if not isinstance(v, dict):
            return v

        # Check for valid operators
        valid_ops = {'$eq', '$ne', '$gt', '$gte', '$lt', '$lte', '$in', '$and', '$or'}
        provided_ops = set(v.keys())

        if not provided_ops.issubset(valid_ops):
            invalid_ops = provided_ops - valid_ops
            raise ValueError(
                f"Invalid operator(s) for field '{field_name}': {invalid_ops}. "
                f"Valid operators are: {sorted(valid_ops)}"
            )

        # Validate $in must be a list
        if '$in' in v and not isinstance(v['$in'], list):
            raise ValueError(f"Field '{field_name}': $in operator requires a list value")

        # Validate $and/$or must be a list
        for op in ['$and', '$or']:
            if op in v and not isinstance(v[op], list):
                raise ValueError(f"Field '{field_name}': ${op[1:]} operator requires a list value")

        return v

    def to_haystack(self, ctx_user_id: str) -> Dict[str, Any]:
        """
        Convert simple filter to Haystack filter format.

        Returns a filter dict compatible with Haystack retrievers.
        Automatically adds user isolation.
        """
        # Start with user isolation condition
        conditions = [{
            "field": "meta.user_id",
            "operator": "==",
            "value": ctx_user_id
        }]

        # Process each field in the filter
        for field, value in self.model_dump().items():
            if field.startswith('$'):
                # Handle logical operators
                conditions.append(self._parse_logical_op(field, value))
            else:
                # Handle field conditions
                conditions.append(self._parse_field_condition(field, value))

        # Return single condition if only one, otherwise AND them together
        if len(conditions) == 1:
            return conditions[0]
        else:
            return {
                "operator": "AND",
                "conditions": conditions
            }

    def _parse_field_condition(self, field: str, value: Any) -> Dict[str, Any]:
        """Parse a simple field condition (with optional operators)."""
        haystack_field = f"meta.{field}"

        # If value is a dict, it contains operators
        if isinstance(value, dict):
            # Handle single operator
            if '$eq' in value:
                return {
                    "field": haystack_field,
                    "operator": "==",
                    "value": value['$eq']
                }
            elif '$ne' in value:
                return {
                    "field": haystack_field,
                    "operator": "!=",
                    "value": value['$ne']
                }
            elif '$gt' in value:
                return {
                    "field": haystack_field,
                    "operator": ">",
                    "value": value['$gt']
                }
            elif '$gte' in value:
                return {
                    "field": haystack_field,
                    "operator": ">=",
                    "value": value['$gte']
                }
            elif '$lt' in value:
                return {
                    "field": haystack_field,
                    "operator": "<",
                    "value": value['$lt']
                }
            elif '$lte' in value:
                return {
                    "field": haystack_field,
                    "operator": "<=",
                    "value": value['$lte']
                }
            elif '$in' in value:
                return {
                    "field": haystack_field,
                    "operator": "in",
                    "value": value['$in']
                }
            else:
                # This shouldn't happen due to validation, but fallback
                return {
                    "field": haystack_field,
                    "operator": "==",
                    "value": value
                }
        else:
            # Simple equality
            return {
                "field": haystack_field,
                "operator": "==",
                "value": value
            }

    def _parse_logical_op(self, op: str, value: List[Any]) -> Dict[str, Any]:
        """Parse logical operators ($and, $or)."""
        if op == '$and':
            return {
                "operator": "AND",
                "conditions": [
                    self._parse_single_condition(item)
                    for item in value
                ]
            }
        elif op == '$or':
            return {
                "operator": "OR",
                "conditions": [
                    self._parse_single_condition(item)
                    for item in value
                ]
            }
        else:
            # Should not happen due to validation
            raise ValueError(f"Unsupported logical operator: {op}")

    def _parse_single_condition(self, condition: Union[Dict[str, Any], Any]) -> Dict[str, Any]:
        """Parse a single condition which could be a field spec or nested logical op."""
        # If it's a dict with exactly one key that doesn't start with $, treat as field spec
        if (isinstance(condition, dict) and
            len(condition) == 1 and
            not list(condition.keys())[0].startswith('$')):
            field, value = next(iter(condition.items()))
            return self._parse_field_condition(field, value)
        # If it's a logical operator dict
        elif isinstance(condition, dict) and any(k.startswith('$') for k in condition.keys()):
            # Recursively handle nested logical ops
            temp_filter = SimpleFilter(**condition)
            return temp_filter.to_haystack("")  # User ID will be added later
        else:
            # Fallback - treat as error case
            raise ValueError(f"Invalid condition format: {condition}")


# Helper function for OpenAPI schema examples
def get_filter_examples() -> Dict[str, Any]:
    """Return example filters for API documentation."""
    return {
        "source_name_filter": {
            "summary": "Search in specific file",
            "value": {"source_name": "report.pdf"}
        },
        "page_range_filter": {
            "summary": "Page range query",
            "value": {"page_number": {"$gte": 1, "$lte": 10}}
        },
        "multiple_files_filter": {
            "summary": "Search across multiple files",
            "value": {"source_name": {"$in": ["report1.pdf", "report2.pdf"]}}
        },
        "table_filter": {
            "summary": "Find only tables",
            "value": {"is_table": True}
        },
        "complex_and_filter": {
            "summary": "Complex AND query",
            "value": {
                "$and": [
                    {"source_name": "report.pdf"},
                    {"page_number": {"$gte": 5, "$lte": 15}},
                    {"is_table": False}
                ]
            }
        },
        "or_filter": {
            "summary": "OR query",
            "value": {
                "$or": [
                    {"source_name": "report.pdf"},
                    {"source_name": "summary.pdf"}
                ]
            }
        }
    }