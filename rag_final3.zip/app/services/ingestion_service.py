"""
Ingestion Service
=================

Business logic for document ingestion — extracted from the ``ingest.py``
endpoint so it can be tested independently of FastAPI.

Responsibilities:
    - Single-file processing through the Haystack indexing pipeline.
    - SHA-256 deduplication via the DocumentVersionRegistry.
    - Version record creation and is_latest flag retirement.
    - Persistent BM25 index synchronisation.
"""

from __future__ import annotations

import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from loguru import logger
from app.schemas.ingest import FileIngestResult, IngestJobDetail, JobStatus
from app.utils.document_version_registry import version_registry
from app.utils.pipeline_registry import PipelineRegistry
from app.utils.user_context import UserContext

logger = logger.bind(submodule=__name__)


# ---------------------------------------------------------------------------
# Single-file processing
# ---------------------------------------------------------------------------


def process_single_file(
    *,
    file_path: Path,
    source_name: str,
    file_bytes: bytes,
    user_ctx: UserContext,
    version_note: str,
    enable_llm_enrichment: bool | None,
    idx_pipeline: Any,
    store: Any | None,
    registry: PipelineRegistry,
    pipeline_name: str,
    ingested_at: str,
    job_id: str,
) -> FileIngestResult:
    """Process one file through the indexing pipeline with versioning.

    Args:
        file_path: Path to the temporary file on disk.
        source_name: Normalised filename (basename only).
        file_bytes: Raw bytes of the uploaded file (for SHA-256 hashing).
        user_ctx: Authenticated user context.
        version_note: Human-readable note for this version.
        enable_llm_enrichment: Override for global LLM enrichment toggle.
        idx_pipeline: Pre-built Haystack indexing pipeline.
        store: Document store reference (for is_latest flag updates).
        registry: Pipeline registry (for settings access).
        ingested_at: ISO 8601 UTC timestamp for this batch.
        job_id: Parent job identifier (for logging).

    Returns:
        A ``FileIngestResult`` describing the outcome.
    """
    # ── Step 1: Dedup + version number assignment ─────────────────────
    check = version_registry.check_and_prepare(
        user_id=user_ctx.user_id,
        source_name=source_name,
        file_bytes=file_bytes,
        version_note=version_note,
    )

    if check.is_duplicate:
        logger.info(
            "Job {} | {} is duplicate (v{}) — skipping ingestion.",
            job_id, source_name, check.version,
        )
        return FileIngestResult(
            filename=source_name,
            status=JobStatus.COMPLETED,
            documents_written=0,
            chunks_created=0,
            version=check.version,
            is_duplicate=True,
            message="Identical content already ingested as latest version.",
        )

    logger.info(
        "Job {} | Starting ingestion for {} (v{})",
        job_id, source_name, check.version,
    )

    # ── Step 2: Run the Haystack pipeline ─────────────────────────────
    settings = registry.get_settings(pipeline_name)
    default_llm_enabled = settings.docling.enrichments.llm_metadata.enabled
    llm_enabled = (
        enable_llm_enrichment if enable_llm_enrichment is not None
        else default_llm_enabled
    )

    output = idx_pipeline.run(
        {
            "converter": {
                "sources": [str(file_path)],
                "meta": {
                    "source_file": str(file_path),
                    "source_name": source_name,
                },
            },
            "meta_enricher": {
                "user_id": user_ctx.user_id,
                "source_name": source_name,
                "source_hash": check.source_hash,
                "version": check.version,
                "is_latest": True,
                "ingested_at": ingested_at,
                "version_note": version_note,
            },
            "llm_enricher": {"enabled": llm_enabled},
        },
        include_outputs_from={"embedder"},
    )

    written = output.get("writer", {}).get("documents_written", 0)
    logger.info(
        "Job {} | Pipeline complete for {}. Written: {} chunks.",
        job_id, source_name, written,
    )

    chunk_ids = _collect_chunk_ids(output, job_id)

    # ── Step 3: Retire old is_latest flags ────────────────────────────
    if store is not None and check.previous_version is not None:
        version_registry.update_latest_flag_in_store(
            document_store=store,
            user_id=user_ctx.user_id,
            source_name=source_name,
            new_latest_version=check.version,
        )

    # ── Step 3b: Sync to persistent BM25 index ───────────────────────
    _sync_bm25(output, job_id, source_name)

    # ── Step 4: Commit version record ─────────────────────────────────
    record = version_registry.commit_version(
        user_id=user_ctx.user_id,
        source_name=source_name,
        source_hash=check.source_hash,
        version=check.version,
        chunk_ids=chunk_ids,
        document_count=written,
        version_note=version_note,
    )

    logger.info(
        "Job {} | {} → v{} | {} chunks written",
        job_id, source_name, record.version, written,
    )

    return FileIngestResult(
        filename=source_name,
        status=JobStatus.COMPLETED,
        documents_written=written,
        chunks_created=written,
        version=record.version,
        is_duplicate=False,
        message=f"Ingested as version {record.version}.",
    )


# ---------------------------------------------------------------------------
# Batch orchestration (replaces _run_ingestion inner loop)
# ---------------------------------------------------------------------------


def run_ingestion_job(
    job: IngestJobDetail,
    user_ctx: UserContext,
    tmp_dir: str,
    file_entries: list[dict],
    pipeline_name: str,
    version_note: str,
    enable_llm_enrichment: bool | None,
    registry: PipelineRegistry,
) -> None:
    """Execute an ingestion job for all files in the batch.

    Designed to run in a background thread. Mutates ``job`` in-place with
    progress and final status.

    Args:
        job: The mutable job detail record.
        user_ctx: Authenticated user context.
        tmp_dir: Temporary directory holding uploaded files.
        file_entries: List of dicts with keys ``path``, ``name``, ``raw_bytes``.
        pipeline_name: Name of the registered pipeline to use.
        version_note: Human-readable note for this version.
        enable_llm_enrichment: Override for global LLM enrichment toggle.
        registry: Pipeline registry.
    """
    job.status = JobStatus.RUNNING
    now_iso = datetime.now(tz=timezone.utc).isoformat()
    job_id = job.job_id

    # Build (or fetch cached) pipeline.
    try:
        idx_pipeline = registry.get_indexing(pipeline_name)
    except Exception as exc:
        logger.error("Job {}: pipeline build failed: {}", job_id, exc)
        job.status = JobStatus.FAILED
        job.error = str(exc)
        job.completed_at = datetime.now(tz=timezone.utc)
        return

    # Grab document store reference for is_latest flag updates.
    try:
        store = idx_pipeline.get_component("writer").document_store
    except Exception:
        store = None

    results: list[FileIngestResult] = []
    total_chunks = 0
    total_written = 0
    any_failed = False

    for entry in file_entries:
        try:
            result = process_single_file(
                file_path=entry["path"],
                source_name=entry["name"],
                file_bytes=entry["raw_bytes"],
                user_ctx=user_ctx,
                version_note=version_note,
                enable_llm_enrichment=enable_llm_enrichment,
                idx_pipeline=idx_pipeline,
                store=store,
                registry=registry,
                pipeline_name=pipeline_name,
                ingested_at=now_iso,
                job_id=job_id,
            )
            results.append(result)
            total_written += result.documents_written
            total_chunks += result.chunks_created

        except Exception as exc:  # noqa: BLE001
            logger.error(
                "Job {} | failed on {}: {}",
                job_id, entry["name"], exc, exc_info=True,
            )
            results.append(
                FileIngestResult(
                    filename=entry["name"],
                    status=JobStatus.FAILED,
                    error=str(exc),
                    version=0,
                )
            )
            any_failed = True

        job.files_processed += 1
        job.total_chunks = total_chunks
        job.total_documents_written = total_written
        job.results = results

    shutil.rmtree(tmp_dir, ignore_errors=True)
    job.status = JobStatus.PARTIAL if any_failed else JobStatus.COMPLETED
    job.completed_at = datetime.now(tz=timezone.utc)
    logger.info(
        "Job {} done | status={} | chunks={}",
        job_id, job.status, total_chunks,
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _collect_chunk_ids(output: dict[str, Any], job_id: str) -> list[str]:
    """Extract chunk IDs from pipeline output for the version registry."""
    try:
        return [
            d.id
            for d in output.get("embedder", {}).get("documents", [])
            if d.id
        ]
    except Exception as exc:
        logger.warning("Job {} | Failed to collect chunk IDs: {}", job_id, exc)
        return []


def _sync_bm25(output: dict[str, Any], job_id: str, source_name: str) -> None:
    """Mirror ingested documents into the persistent BM25 index."""
    try:
        from config.settings import get_settings

        bm25_cfg = get_settings().document_store.bm25_persistence
        if not bm25_cfg.enabled:
            return

        from app.repositories.bm25_repository import get_bm25_manager

        bm25_manager = get_bm25_manager(persist_path=bm25_cfg.persist_path)
        embedded_docs = output.get("embedder", {}).get("documents", [])
        if embedded_docs:
            bm25_manager.sync_documents(embedded_docs)
            logger.debug(
                "Job {} | {}: synced {} docs to BM25 index.",
                job_id, source_name, len(embedded_docs),
            )
    except Exception as bm25_exc:
        logger.warning(
            "Job {} | BM25 sync failed for {}: {} (non-fatal)",
            job_id, source_name, bm25_exc,
        )
