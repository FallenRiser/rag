"""
Query Service
=============

Business logic for RAG query execution — extracted from the ``query.py``
endpoint so it can be tested independently of FastAPI.

Responsibilities:
    - Non-streaming RAG execution (retrieval → generation).
    - SSE streaming orchestration.
    - Filter construction (user isolation + auto-filter).
    - Response parsing and source formatting.
    - Pipeline name resolution (HyDE toggle).
"""

from __future__ import annotations

import asyncio
import json
import queue
import threading
from typing import Any, AsyncGenerator, TYPE_CHECKING

from loguru import logger
from app.schemas.query import (
    QueryRequest,
    QueryResponse,
    SearchRequest,
    SearchResponse,
    SourceDocument,
)
from app.services.retrieval_service import (
    retrieve_single_query,
    retrieve_with_multi_query,
)

if TYPE_CHECKING:
    from config.settings import AppSettings
    from app.utils.pipeline_registry import PipelineRegistry
    from app.utils.user_context import UserContext

logger = logger.bind(submodule=__name__)


# ---------------------------------------------------------------------------
# Pipeline name resolution
# ---------------------------------------------------------------------------


def resolve_pipeline_name(
    request: QueryRequest,
    settings: "AppSettings",
    registry: "PipelineRegistry",
) -> str:
    """Determine which pipeline variant to run based on HyDE overrides.

    Args:
        request: The incoming query containing potential HyDE overrides.
        settings: Global settings containing default HyDE preference.
        registry: Used to verify existence of fallback pipeline variants.

    Returns:
        The name of the pipeline variant to execute.
    """
    pipeline_name = request.pipeline_name
    use_hyde = (
        request.enable_hyde
        if request.enable_hyde is not None
        else settings.query.hyde.enabled
    )

    if not use_hyde and settings.query.hyde.enabled:
        fallback_name = f"{pipeline_name}_no_hyde"
        if fallback_name in registry.registered_names():
            return fallback_name
        logger.warning(
            "HyDE disable requested but fallback pipeline '{}' not registered. Ignoring.",
            fallback_name,
        )

    return pipeline_name


# ---------------------------------------------------------------------------
# Filter construction
# ---------------------------------------------------------------------------


def build_base_filters(
    request: QueryRequest | SearchRequest,
    settings: "AppSettings",
    ctx: "UserContext",
    auto_filter_haystack: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build the comprehensive retrieval filter (isolation + user filters + chunking).

    Args:
        request: The incoming request (for user-supplied filters and version).
        settings: Global settings (for chunking strategy).
        ctx: Authenticated user context.
        auto_filter_haystack: Optional auto-extracted entity filter.

    Returns:
        A single Haystack compound filter dict.
    """
    version = getattr(request, "version", None)
    if version is not None and version > 0:
        from app.utils.user_isolation import version_filter
        base_filter = version_filter(ctx, version)
    else:
        from app.utils.user_isolation import latest_filter
        base_filter = latest_filter(ctx)

    conditions = [base_filter]
    if request.filters is not None:
        conditions.append(request.filters.to_haystack(ctx.user_id))
    if auto_filter_haystack is not None:
        conditions.append(auto_filter_haystack)

    current_filter = (
        {"operator": "AND", "conditions": conditions}
        if len(conditions) > 1
        else conditions[0]
    )


    return current_filter


# ---------------------------------------------------------------------------
# Auto-filter extraction
# ---------------------------------------------------------------------------


async def extract_auto_filters(
    query: str, builder: Any
) -> dict[str, Any] | None:
    """Use the configured generator to dynamically extract entities for filtering.

    Args:
        query: The natural-language query to extract entities from.
        builder: Pipeline builder with access to the generator.

    Returns:
        A Haystack filter dict, or None if no entity was extracted.
    """
    try:
        backend = builder.query_cfg.generator.backend
        extra_kwargs: dict[str, Any] = {}
        if backend.value == "openai":
            extra_kwargs["response_format"] = {"type": "json_object"}
        elif backend.value == "ollama":
            extra_kwargs["format"] = "json"

        generator = builder._build_generator(extra_generation_kwargs=extra_kwargs)
        from haystack.dataclasses import ChatMessage

        prompt = (
            f"Extract the primary entity or subject from this query: '{query}'. "
            "Return a JSON object with an 'entity' string field. "
            "If no clear specific entity exists, return an empty JSON object {}."
        )

        loop = asyncio.get_running_loop()
        res = await loop.run_in_executor(
            None,
            lambda: generator.run(messages=[ChatMessage.from_user(prompt)]),
        )
        reply = res["replies"][0].content

        data = json.loads(reply)
        entity = data.get("entity")
        if not entity:
            return None

        return {
            "field": "meta.entities",
            "operator": "contains",
            "value": {"entity": entity},
        }
    except Exception as exc:
        logger.warning("Failed to extract auto-filter: {}", exc)
        return None


# ---------------------------------------------------------------------------
# Pipeline input construction
# ---------------------------------------------------------------------------


def build_pipeline_input(
    request: QueryRequest,
    settings: "AppSettings",
    ctx: "UserContext",
    pipeline: Any,
    isolation_filter: dict[str, Any],
) -> dict[str, Any]:
    """Construct the input dictionary for ``pipeline.run()``.

    Args:
        request: The incoming query parameters.
        settings: Global settings.
        ctx: Authenticated user context.
        pipeline: The loaded Haystack Pipeline object.
        isolation_filter: Pre-compiled filter containing isolation logic.

    Returns:
        A structured dictionary matching the Haystack pipeline input schema.
    """
    inputs: dict[str, Any] = {
        "prompt_builder": {"query": request.query},
        "answer_builder": {"query": request.query},
    }

    search_type = (
        request.search_type
        or settings.query.retrieval.search_type.value
    )

    # Vector search components
    if search_type in ["embedding", "hybrid"]:
        if "embedding_retriever" in pipeline.graph.nodes:
            inputs["embedding_retriever"] = {
                "top_k": request.top_k,
                "filters": isolation_filter,
            }
        if "hyde_prompt_builder" in pipeline.graph.nodes:
            inputs["hyde_prompt_builder"] = {"query": request.query}
            inputs["hyde_adapter"] = {"query": request.query}
        elif "text_embedder" in pipeline.graph.nodes:
            inputs["text_embedder"] = {"text": request.query}

    # BM25 search components
    if search_type in ["bm25", "hybrid"]:
        if "bm25_retriever" in pipeline.graph.nodes:
            inputs["bm25_retriever"] = {
                "query": request.query,
                "top_k": request.top_k,
                "filters": isolation_filter,
            }

    # Reranker
    if "reranker" in pipeline.graph.nodes:
        instance = pipeline.get_component("reranker")
        if not hasattr(instance, "word_count_threshold"):
            inputs["reranker"] = {"query": request.query}

    # Context truncation
    inputs["context_truncator"] = {}
    if request.max_context_docs is not None and request.max_context_docs > 0:
        inputs["context_truncator"]["max_docs"] = request.max_context_docs
    if request.max_chars_per_doc is not None and request.max_chars_per_doc > 0:
        inputs["context_truncator"]["max_chars_per_doc"] = request.max_chars_per_doc

    return inputs


# ---------------------------------------------------------------------------
# Response parsing
# ---------------------------------------------------------------------------


def parse_query_result(
    request: QueryRequest,
    result: dict[str, Any],
    settings: "AppSettings",
) -> QueryResponse:
    """Parse raw Haystack pipeline output into a structured ``QueryResponse``.

    Args:
        request: The original request (for query string and include_sources).
        result: The output dictionary from ``pipeline.run()``.
        settings: Global settings for source limits.

    Returns:
        A validated ``QueryResponse`` model.
    """
    answers = result.get("answer_builder", {}).get("answers", [])
    answer_text = answers[0].data if answers else "No answer generated."

    raw_docs: list[Any] = []
    if answers and hasattr(answers[0], "documents") and answers[0].documents:
        raw_docs = answers[0].documents

    sources = _format_sources(raw_docs, request.include_sources, settings)

    return QueryResponse(
        query=request.query,
        answer=answer_text,
        pipeline_name=request.pipeline_name,
        sources=sources,
        meta={
            "sources_retrieved": len(raw_docs),
            "sources_returned": len(sources),
        },
    )


def format_search_results(docs: list[Any]) -> list[SourceDocument]:
    """Convert Haystack Documents to ``SourceDocument`` schema objects.

    Args:
        docs: List of Haystack Document objects.

    Returns:
        List of serialisable ``SourceDocument`` models.
    """
    return [
        SourceDocument(
            document_id=doc.id or "",
            content=doc.content or "",
            score=doc.score,
            source_file=(doc.meta or {}).get("source_file"),
            page_number=(doc.meta or {}).get("page_number"),
            headings=(doc.meta or {}).get("headings", []),
            is_table=(doc.meta or {}).get("is_table", False),
            is_picture=(doc.meta or {}).get("is_picture", False),
            picture_caption=(doc.meta or {}).get("picture_caption"),
            chunk_index=(doc.meta or {}).get("chunk_index"),
        )
        for doc in docs
    ]


# ---------------------------------------------------------------------------
# SSE streaming
# ---------------------------------------------------------------------------


def build_streaming_response(
    request: QueryRequest,
    registry: "PipelineRegistry",
    ctx: "UserContext",
    pipeline_name: str,
) -> dict[str, Any]:
    """Build the components for SSE token streaming.

    Returns a dict with ``token_queue``, ``thread``, and ``event_generator``.
    This is called by the endpoint to create a StreamingResponse.
    """
    from app.utils.user_isolation import merge_with_user_filter

    token_queue: queue.Queue[str | None] = queue.Queue()

    def streaming_callback(chunk: Any) -> None:
        content = getattr(chunk, "content", None) or ""
        if content:
            token_queue.put(content)

    def run_pipeline() -> None:
        try:
            pipeline = registry.get_query(pipeline_name)
            isolation_filter = merge_with_user_filter(ctx, request.filters)
            pipeline_inputs: dict[str, Any] = {
                "prompt_builder": {"query": request.query},
                "answer_builder": {"query": request.query},
            }

            pipeline_settings = registry.get_settings(pipeline_name)
            search_type = (
                request.search_type
                or pipeline_settings.query.retrieval.search_type.value
            )

            if search_type in ["embedding", "hybrid"]:
                if "embedding_retriever" in pipeline.graph.nodes:
                    pipeline_inputs["embedding_retriever"] = {
                        "top_k": request.top_k,
                        "filters": isolation_filter,
                    }

            if search_type in ["bm25", "hybrid"]:
                if "bm25_retriever" in pipeline.graph.nodes:
                    pipeline_inputs["bm25_retriever"] = {
                        "query": request.query,
                        "top_k": request.top_k,
                        "filters": isolation_filter,
                    }

            if search_type in ["embedding", "hybrid"]:
                if "hyde_prompt_builder" in pipeline.graph.nodes:
                    pipeline_inputs["hyde_prompt_builder"] = {"query": request.query}
                    pipeline_inputs["hyde_adapter"] = {"query": request.query}
                elif "text_embedder" in pipeline.graph.nodes:
                    pipeline_inputs["text_embedder"] = {"text": request.query}

            if request.max_context_docs or request.max_chars_per_doc:
                pipeline_inputs["context_truncator"] = {}
                if request.max_context_docs:
                    pipeline_inputs["context_truncator"]["max_docs"] = (
                        request.max_context_docs
                    )
                if request.max_chars_per_doc:
                    pipeline_inputs["context_truncator"]["max_chars_per_doc"] = (
                        request.max_chars_per_doc
                    )

            pipeline.run(
                pipeline_inputs,
                include_outputs_from={
                    "generator": {"streaming_callback": streaming_callback}
                },
            )
        except Exception as exc:
            logger.error("Streaming pipeline error: {}", exc, exc_info=True)
        finally:
            token_queue.put(None)

    thread = threading.Thread(target=run_pipeline, daemon=True)
    thread.start()

    async def event_generator() -> AsyncGenerator[str, None]:
        while True:
            try:
                token = token_queue.get(timeout=60)
            except queue.Empty:
                yield 'data: {"error": "stream timeout"}\n\n'
                break
            if token is None:
                yield "data: [DONE]\n\n"
                break
            payload = json.dumps({"token": token})
            yield f"data: {payload}\n\n"

    return {
        "token_queue": token_queue,
        "thread": thread,
        "event_generator": event_generator,
    }


# ---------------------------------------------------------------------------
# Helpers (private)
# ---------------------------------------------------------------------------


def _format_sources(
    raw_docs: list[Any],
    include_sources: bool,
    settings: "AppSettings",
) -> list[SourceDocument]:
    """Format raw Haystack Documents into SourceDocument models."""
    if not include_sources:
        return []

    max_sources = settings.query.answer.max_sources
    return [
        SourceDocument(
            document_id=doc.id or "",
            content=doc.content or "",
            score=doc.score if settings.query.answer.include_scores else None,
            source_file=(doc.meta or {}).get("source_file"),
            page_number=(doc.meta or {}).get("page_number"),
            headings=(doc.meta or {}).get("headings", []),
            is_table=(doc.meta or {}).get("is_table", False),
            is_picture=(doc.meta or {}).get("is_picture", False),
            picture_caption=(doc.meta or {}).get("picture_caption"),
            chunk_index=(doc.meta or {}).get("chunk_index"),
        )
        for doc in raw_docs[:max_sources]
    ]
