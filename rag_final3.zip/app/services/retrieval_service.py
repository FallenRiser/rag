"""
Retrieval Service
=================

Pure retrieval logic — extracted from ``query.py`` so it can be reused
by both the ``/v1/query`` (RAG) and ``/v1/search`` (retrieval-only) endpoints.

Responsibilities:
    - Single-query retrieval (embedding, BM25, or hybrid).
    - Multi-query expansion via Haystack's QueryExpander + RRF fusion.
    - Reranking (LostInTheMiddle, LLM, CrossEncoder).
    - Component warm-up lifecycle management.
"""

from __future__ import annotations

import asyncio
from typing import Any, TYPE_CHECKING

from loguru import logger

if TYPE_CHECKING:
    from app.schemas.query import QueryRequest, SearchRequest
    from app.utils.query_pipeline import QueryPipelineBuilder

logger = logger.bind(submodule=__name__)


# ---------------------------------------------------------------------------
# Component warm-up
# ---------------------------------------------------------------------------


def warm_up_component(comp: Any, label: str) -> None:
    """Call ``warm_up()`` on a Haystack component if available.

    Args:
        comp: A Haystack component instance.
        label: Human-readable label for logging.
    """
    if hasattr(comp, "warm_up"):
        logger.debug("Warming up component: {}", label)
        comp.warm_up()


# ---------------------------------------------------------------------------
# Single-query retrieval
# ---------------------------------------------------------------------------


async def retrieve_single_query(
    query: str,
    request: "QueryRequest | SearchRequest",
    builder: "QueryPipelineBuilder",
    store: Any,
    isolation_filter: dict[str, Any],
    *,
    text_embedder: Any | None = None,
    embedding_retriever: Any | None = None,
    bm25_retriever: Any | None = None,
) -> list[Any]:
    """Execute a single-query retrieval branch (Embedding, BM25, or Hybrid).

    Args:
        query: The query string to embed/search.
        request: The original request (for top_k, search_type, reranker).
        builder: Pipeline builder for constructing retriever components.
        store: Haystack document store to search against.
        isolation_filter: Pre-built Haystack filter for user isolation.
        text_embedder: Optional pre-warmed text embedder.
        embedding_retriever: Optional pre-warmed embedding retriever.
        bm25_retriever: Optional pre-warmed BM25 retriever.

    Returns:
        List of Haystack Document objects, optionally reranked.
    """
    from app.utils.embedding import EmbeddingFactory

    docs: list[Any] = []
    search_type = (
        getattr(request, "search_type", None)
        or builder.query_cfg.retrieval.search_type.value
    )
    loop = asyncio.get_running_loop()

    # ── 1. Vector search branch ───────────────────────────────────────
    if search_type in ["embedding", "hybrid"]:
        if text_embedder is None:
            text_embedder = EmbeddingFactory(
                builder.settings.embedding
            ).build_text_embedder()
            warm_up_component(text_embedder, "text_embedder (standalone)")

        _q = query
        embed_result = await loop.run_in_executor(
            None, lambda q=_q: text_embedder.run(text=q)
        )
        query_embedding = embed_result["embedding"]
        logger.debug(
            "Embedded query '{}…' → vector dim={}",
            query[:50], len(query_embedding),
        )

        if embedding_retriever is None:
            embedding_retriever = builder._build_embedding_retriever(
                store, request.top_k
            )
            warm_up_component(embedding_retriever, "embedding_retriever (standalone)")

        _emb = query_embedding
        v_result = await loop.run_in_executor(
            None,
            lambda emb=_emb: embedding_retriever.run(
                query_embedding=emb, filters=isolation_filter
            ),
        )
        docs = v_result.get("documents", [])

    # ── 2. BM25 search branch ─────────────────────────────────────────
    if search_type in ["bm25", "hybrid"]:
        if bm25_retriever is None:
            bm25_retriever = builder._build_bm25_retriever(store, request.top_k)
            warm_up_component(bm25_retriever, "bm25_retriever (standalone)")

        _q = query
        b_result = await loop.run_in_executor(
            None, lambda q=_q: bm25_retriever.run(query=q, filters=isolation_filter)
        )
        b_docs = b_result.get("documents", [])

        if search_type == "hybrid":
            from haystack.components.joiners import DocumentJoiner

            joiner = DocumentJoiner(join_mode="reciprocal_rank_fusion")
            merged = joiner.run(documents=[docs, b_docs])
            docs = merged.get("documents", [])
        else:
            docs = b_docs

    # ── 3. Reranking (optional) ───────────────────────────────────────
    docs = await _apply_reranking(query, docs, request, builder, loop)

    return docs


# ---------------------------------------------------------------------------
# Multi-query retrieval
# ---------------------------------------------------------------------------


async def retrieve_with_multi_query(
    request: "QueryRequest | SearchRequest",
    builder: "QueryPipelineBuilder",
    store: Any,
    isolation_filter: dict[str, Any],
) -> list[Any]:
    """Run retrieval for multiple query variants in parallel and fuse via RRF.

    Args:
        request: The original request (for top_k, search_type).
        builder: Pipeline builder for constructing components.
        store: Haystack document store.
        isolation_filter: Pre-built Haystack filter for user isolation.

    Returns:
        List of Haystack Documents, fused and ranked by RRF.
    """
    from app.utils.embedding import EmbeddingFactory

    count = request.multi_query_count or builder.query_cfg.multi_query.n_expansions
    variants = await _generate_query_variants(request.query, count, builder)

    if request.query not in variants:
        variants.insert(0, request.query)

    logger.info(
        "Multi-Query: retrieving for {} variants (top_k={}).",
        len(variants), request.top_k,
    )

    # Pre-warm shared components ONCE
    search_type = (
        getattr(request, "search_type", None)
        or builder.query_cfg.retrieval.search_type.value
    )

    shared_embedder = None
    shared_retriever = None
    shared_bm25 = None

    if search_type in ["embedding", "hybrid"]:
        shared_embedder = EmbeddingFactory(
            builder.settings.embedding
        ).build_text_embedder()
        warm_up_component(shared_embedder, "text_embedder (multi-query shared)")
        shared_retriever = builder._build_embedding_retriever(store, request.top_k)
        warm_up_component(shared_retriever, "embedding_retriever (multi-query shared)")

    if search_type in ["bm25", "hybrid"]:
        shared_bm25 = builder._build_bm25_retriever(store, request.top_k)
        warm_up_component(shared_bm25, "bm25_retriever (multi-query shared)")

    # Parallel retrieval
    tasks = [
        retrieve_single_query(
            variant, request, builder, store, isolation_filter,
            text_embedder=shared_embedder,
            embedding_retriever=shared_retriever,
            bm25_retriever=shared_bm25,
        )
        for variant in variants
    ]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    clean_results: list[list[Any]] = []
    for i, (variant, result) in enumerate(zip(variants, results)):
        if isinstance(result, Exception):
            logger.error(
                "  Variant {} ('{}…'): FAILED — {}",
                i, variant[:60], result,
            )
            clean_results.append([])
        else:
            logger.debug(
                "  Variant {} ('{}…'): {} docs retrieved.",
                i, variant[:60], len(result),
            )
            clean_results.append(result)

    # Fuse with RRF
    from app.utils.query_pipeline import rrf_merge

    fused_docs = rrf_merge(clean_results)
    final_docs = fused_docs[: request.top_k]
    logger.info(
        "Multi-Query: RRF fusion complete. {} unique → top {} returned.",
        len(fused_docs), len(final_docs),
    )

    return final_docs


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _generate_query_variants(
    query: str, count: int, builder: "QueryPipelineBuilder"
) -> list[str]:
    """Generate alternative query versions using Haystack's QueryExpander.

    Args:
        query: The original query string.
        count: Total number of query variants desired.
        builder: Pipeline builder with access to the query expander.

    Returns:
        List of query variant strings.
    """
    logger.info("Multi-Query: generating {} variants for: '{}'", count, query)

    expander = builder._build_query_expander()
    mq_cfg = builder.query_cfg.multi_query
    n = count - 1 if mq_cfg.include_original_query else count

    loop = asyncio.get_running_loop()
    try:
        res = await loop.run_in_executor(
            None,
            lambda: expander.run(query=query, n_expansions=max(n, 1)),
        )
        variants = res["queries"]
        logger.info(
            "Multi-Query: got {} queries (incl. original if configured).",
            len(variants),
        )
        for i, v in enumerate(variants):
            logger.debug("  [Variant {}]: {}", i, v)
        return variants
    except Exception as exc:
        logger.warning(
            "Multi-Query expansion failed: {}. Falling back to original query.",
            exc,
        )
        return [query]


async def _apply_reranking(
    query: str,
    docs: list[Any],
    request: "QueryRequest | SearchRequest",
    builder: "QueryPipelineBuilder",
    loop: asyncio.AbstractEventLoop,
) -> list[Any]:
    """Apply reranking to retrieved documents if configured.

    Args:
        query: The query string (for rerankers that need it).
        docs: Documents to rerank.
        request: The original request (for reranker override).
        builder: Pipeline builder for constructing the reranker.
        loop: The running event loop.

    Returns:
        Reranked documents, or the original list if no reranking.
    """
    reranker_strategy = (
        getattr(request, "reranker", None)
        or builder.query_cfg.reranker.strategy.value
    )

    if reranker_strategy == "none" or not docs:
        return docs

    ranker_builders = {
        "lost_in_middle": builder._build_lost_in_middle_ranker,
        "llm": builder._build_llm_ranker,
        "cross_encoder": builder._build_cross_encoder_ranker,
    }

    ranker_builder = ranker_builders.get(reranker_strategy)
    if not ranker_builder:
        return docs

    ranker = ranker_builder()
    warm_up_component(ranker, f"reranker ({reranker_strategy})")

    _q, _docs = query, docs
    if reranker_strategy == "lost_in_middle":
        rank_result = await loop.run_in_executor(
            None, lambda d=_docs: ranker.run(documents=d)
        )
    else:
        rank_result = await loop.run_in_executor(
            None, lambda q=_q, d=_docs: ranker.run(query=q, documents=d)
        )

    return rank_result.get("documents", [])
