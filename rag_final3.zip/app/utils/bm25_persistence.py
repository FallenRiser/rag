"""Backward-compatibility shim — BM25 persistence has moved to app.repositories.bm25_repository."""
from app.repositories.bm25_repository import (  # noqa: F401
    BM25PersistenceManager,
    get_bm25_manager,
    get_bm25_store,
)
