"""
IndexingPipelineBuilder
========================

Wires DoclingConverter → DocumentCleaner → [Chunker] → MetadataEnricher
→ DocumentEmbedder → DocumentWriter into a single Haystack Pipeline.

document_aware special case
----------------------------
When ``chunking.strategy = "document_aware"``, ``ChunkingFactory.build()``
returns ``None``. In that case:

  - DoclingConverter is built with HybridChunker embedded.
  - No cleaner or splitter component is added to the pipeline.
  - converter.documents connects directly to meta_enricher.documents.

All other strategies
--------------------
  converter → cleaner → chunker → meta_enricher → embedder → writer
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from config.models import ChunkingStrategy
from config.settings import AppSettings
from loguru import logger
from app.utils.chunking import ChunkingFactory
from app.utils.docling_pipeline import DoclingPipelineBuilder
from app.utils.embedding import EmbeddingFactory
from app.utils.metadata_enricher import MetadataEnricher

if TYPE_CHECKING:
    from haystack import Pipeline

logger = logger.bind(submodule=__name__)
try:
    from haystack import component, Document
    @component
    class StageLogger:
        """Custom component to log document counts and snippets at various stages."""
        def __init__(self, stage_name: str):
            self.stage_name = stage_name

        @component.output_types(documents=list[Document])
        def run(self, documents: list[Document]):
            logger.info(f"--- Ingestion Stage: {self.stage_name} ---")
            logger.info(f"Processed {len(documents)} documents.")
            if documents:
                snippet = (documents[0].content or "")[:150].replace("\n", " ")
                logger.debug(f"Sample doc [ID: {documents[0].id}]: {snippet}...")
            return {"documents": documents}
except ImportError:
    # Stub for environments without Haystack
    class StageLogger:
        def __init__(self, stage_name: str): pass
        def run(self, documents: list): return {"documents": documents}


class IndexingPipelineBuilder:
    """
    Build the Haystack ingestion pipeline from AppSettings.

    Usage::

        pipeline = IndexingPipelineBuilder(settings).build()
        result   = pipeline.run({
            "converter":    {"sources": ["report.pdf"]},
            "meta_enricher": {
                "user_id": "alice", "source_name": "report.pdf",
                "source_hash": "abc…", "version": 1,
                "is_latest": True, "ingested_at": "2024-01-01T00:00:00+00:00",
            },
        })
    """

    def __init__(self, settings: AppSettings) -> None:
        self.settings = settings

    def build(self) -> "Pipeline":
        from haystack import Pipeline

        cfg_chunk   = self.settings.chunking
        cfg_docling = self.settings.docling
        is_doc_aware = cfg_chunk.strategy == ChunkingStrategy.DOCUMENT_AWARE

        logger.info(
            "Building indexing pipeline | strategy={} | export={} | embedding={}",
            cfg_chunk.strategy.value,
            cfg_docling.export.type.value,
            self.settings.embedding.provider.value,
        )

        pipeline = Pipeline()

        # ── 1. Converter ─────────────────────────────────────────────────
        # Docling's StandardPdfPipeline unconditionally rasterizes every page via
        # pypdfium2 for its RT-DETR layout AI model. This causes std::bad_alloc on
        # large PDFs on memory-constrained machines. When enrichments (OCR, captioning,
        # table structure) are disabled, we fall back to Haystack's PyPDFToDocument
        # which uses pure-Python pypdf — zero C++ page rendering, zero OOM risk.
        converter = self._build_converter(cfg_docling, cfg_chunk, is_doc_aware)
        pipeline.add_component("converter", converter)
        pipeline.add_component("log_after_convert", StageLogger("Conversion"))
        pipeline.connect("converter.documents", "log_after_convert.documents")
        
        # ── 2 & 3. DocumentCleaner + Chunker (skipped for document_aware) ──
        factory = ChunkingFactory(cfg_chunk, self.settings.embedding)
        chunker: Any = factory.build()   # None when document_aware

        if not is_doc_aware:
            cleaner = factory.build_cleaner()
            pipeline.add_component("cleaner", cleaner)
            pipeline.add_component("chunker", chunker)
            pipeline.add_component("log_after_chunk", StageLogger("Chunking"))

            pipeline.connect("log_after_convert.documents", "cleaner.documents")
            pipeline.connect("cleaner.documents",   "chunker.documents")
            pipeline.connect("chunker.documents",   "log_after_chunk.documents")
            last_output = "log_after_chunk.documents"
        else:
            last_output = "log_after_convert.documents"

        # ── 4. MetadataEnricher ───────────────────────────────────────────
        pipeline.add_component("meta_enricher", MetadataEnricher())
        pipeline.add_component("log_after_enrich", StageLogger("Enrichment"))
        
        pipeline.connect(last_output, "meta_enricher.documents")
        pipeline.connect("meta_enricher.documents", "log_after_enrich.documents")
        
        last_output = "log_after_enrich.documents"

        # ── 4.5 Optional LLM Enrichment ───────────────────────────────────
        from app.utils.llm_enricher import build_llm_metadata_extractor, OptionalLLMEnricher
        
        llm_extractor = build_llm_metadata_extractor(self.settings)
        pipeline.add_component("llm_enricher", OptionalLLMEnricher(llm_extractor))
        pipeline.add_component("log_after_llm_enrich", StageLogger("LLM Enrichment"))
        
        pipeline.connect(last_output, "llm_enricher.documents")
        pipeline.connect("llm_enricher.documents", "log_after_llm_enrich.documents")
        
        last_output = "log_after_llm_enrich.documents"

        # ── 5. DocumentEmbedder ───────────────────────────────────────────
        embedder = EmbeddingFactory(self.settings.embedding).build_document_embedder()
        pipeline.add_component("embedder", embedder)
        pipeline.connect(last_output, "embedder.documents")

        # ── 6. DocumentWriter ─────────────────────────────────────────────
        from app.utils.document_store import StoreFactory
        from haystack.components.writers import DocumentWriter

        store  = StoreFactory(self.settings.document_store).build()
        writer = DocumentWriter(document_store=store)
        pipeline.add_component("writer", writer)
        pipeline.connect("embedder.documents", "writer.documents")

        logger.info("Indexing pipeline built OK.")
        return pipeline

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _build_converter(self, cfg_docling: Any, cfg_chunk: Any, is_doc_aware: bool) -> Any:
        """
        Return the appropriate document converter component.

        Uses ``BatchedDoclingConverter`` which splits large PDFs into small
        page-range batches (default 15 pages each), converts each batch
        through Docling independently, and merges all output documents.
        This preserves Docling's full structural extraction while preventing
        OOM (std::bad_alloc) on large PDFs.
        """
        from app.utils.batched_docling_converter import BatchedDoclingConverter

        batch_size = 15  # pages per batch; lower = less memory
        logger.info(
            "Converter: BatchedDoclingConverter (batch_size={} pages) — "
            "full Docling extraction, memory-safe",
            batch_size,
        )
        return BatchedDoclingConverter(
            docling_config=cfg_docling,
            batch_size=batch_size,
            export_type=cfg_docling.export.type.value,
        )