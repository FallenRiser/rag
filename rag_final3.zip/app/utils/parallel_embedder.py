"""
Parallel wrappers for embedding components.
"""
from typing import Any, Dict, List, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import replace

from haystack import component
from haystack.components.embedders import OpenAIDocumentEmbedder
from haystack.dataclasses import Document
from haystack.utils import batched
from openai import APIError
from loguru import logger

logger = logger.bind(submodule=__name__)

class ParallelOpenAIDocumentEmbedder(OpenAIDocumentEmbedder):
    """
    Extends OpenAIDocumentEmbedder to embed batches in parallel.
    Useful for very large documents with hundreds of chunks to speed up indexing.
    """
    def __init__(self, *args, max_workers: int = 4, **kwargs):
        super().__init__(*args, **kwargs)
        self.max_workers = max_workers

    def _embed_batch(
        self, texts_to_embed: Dict[str, str], batch_size: int
    ) -> Tuple[Dict[str, List[float]], Dict[str, Any]]:
        """
        Embed a list of texts in batches, executing batches in parallel.
        """
        doc_ids_to_embeddings: Dict[str, List[float]] = {}
        meta: Dict[str, Any] = {"usage": {"prompt_tokens": 0, "total_tokens": 0}}

        batches = list(batched(texts_to_embed.items(), batch_size))
        if not batches:
            return doc_ids_to_embeddings, meta
            
        def _process_batch(batch):
            args: Dict[str, Any] = {"model": self.model, "input": [b[1] for b in batch], "encoding_format": "float"}
            if self.dimensions is not None:
                args["dimensions"] = self.dimensions

            response = self.client.embeddings.create(**args)
            return batch, response

        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {executor.submit(_process_batch, b): b for b in batches}
            for future in as_completed(futures):
                try:
                    batch, response = future.result()
                    
                    embeddings = [el.embedding for el in response.data]
                    doc_ids_to_embeddings.update(dict(zip((b[0] for b in batch), embeddings, strict=True)))
                    
                    if "model" not in meta:
                        meta["model"] = response.model
                        
                    meta["usage"]["prompt_tokens"] += response.usage.prompt_tokens
                    meta["usage"]["total_tokens"] += response.usage.total_tokens
                    
                except APIError as exc:
                    batch = futures[future]
                    ids = ", ".join(b[0] for b in batch)
                    logger.exception("Failed embedding of documents {} caused by {}", ids, exc)
                    if self.raise_on_failure:
                        raise exc

        return doc_ids_to_embeddings, meta
