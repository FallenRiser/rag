"""Backward-compatibility shim — tracing has moved to app.observability.tracing."""
from app.observability.tracing import setup_tracing  # noqa: F401
